function msg()
{
    document.write("aravind REddy")
}