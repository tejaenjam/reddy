let fq:string="aravind Reddy"
let si:string='Keshireddy'
let sq='hello,my name is '+fq+'and surname is'+si
console.log(sq)
let sq1=`hello,my name is ${fq}
my surname is ${si}`
console.log(sq1)
