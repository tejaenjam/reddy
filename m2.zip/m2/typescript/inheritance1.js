var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var te1 = /** @class */ (function () {
    function te1(f, p) {
        this.f = f;
        this.p = p;
    }
    te1.prototype.dis = function () {
        return this.f + " " + this.p;
    };
    return te1;
}());
var te2 = /** @class */ (function (_super) {
    __extends(te2, _super);
    function te2(id1, f1, p1) {
        var _this = _super.call(this, f1, p1) || this;
        _this.id = id1;
        return _this;
    }
    return te2;
}(te1));
var q1 = new te2(12, 123, "as");
console.log(q1);
