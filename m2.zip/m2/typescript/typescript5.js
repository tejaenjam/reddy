function add(x, y) {
    return x + y;
}
var s1 = function (x, y) { return x + y; };
add(14, 2);
s1(19, 2);
console.log(add);
console.log(s1);
var s2 = function (x, y) { return x + y; };
s2(1, 2);
console.log(s2);
var s3 = function (x, y) { return x + y; };
s3(1, 2);
console.log(s3);
var s4 = function (x, y) { return x + y; };
s4(1, 3);
console.log(s4);
var s5 = function () { return console.log("fn without return"); };
s5();
