function add() {
    var x = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        x[_i] = arguments[_i];
    }
    var rew = 0;
    for (var i = 0; i < x.length; i++) {
        rew += x[i];
    }
    return rew;
}
var nums = [2, 3, 4, 5, 6];
var rew = add.apply(void 0, nums);
