var fu=()=>'response'
var a=10;
var b=false;
var c="wel"
function m1():string
{
   return "a" 
}
var m1=m1();


