function add(x, y, z) {
    var re;
    if (typeof x == "number" && typeof y == "number" && typeof z == "number") {
        re = x + y + z;
    }
    else {
        re = x + y + "       " + z;
    }
    return re;
}
var re11 = add(4, 3, 2);
console.log(re11);
var re2 = add("wel", "hel", "hi");
console.log(re2);
