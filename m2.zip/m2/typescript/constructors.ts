/*
class te {
    f;
    p;
}
var a12=new  te();
a12.f="aravind"
a12.p="reddy"
console.log(a12.f+"  "+a12.p)
*/
/*
class te {
    f;
    p;
    constructor(f:string,p:string)
    {
        this.f=f;
        this.p=p;
    }
}
var a12=new  te("ara","vind");
console.log(a12.f+"  "+a12.p)
*/
class te {
    f:number;
    p:string;
    constructor(f:number,p:string)
    {
        this.f=f;
        this.p=p;
    }
    dis()
    {
        return this.f+" "+this.p
    }
}
var a12=new  te(789,"vind");
console.log(a12.dis())
