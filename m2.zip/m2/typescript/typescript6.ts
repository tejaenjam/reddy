function add(x:string,y:string,z:string):string;
function add(x:number,y:number,z:number):number;
function add(x:any,y:any,z:any):any{
    let re:any;
    if(typeof x=="number"&&typeof y=="number"&&typeof z=="number")
    {
        var p=x+y;
        re=x+y+z;
    }else{
        re=x+y+"       "+z;
    }
    return re;
    p=p+1;
    console.log(p)
}

let re11=add(4,3,2);
console.log(re11)
let re2=add("wel","hel","hi");
console.log(re2)