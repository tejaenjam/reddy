function add(x:number,y:number):number
{
    return x+y;
}
let s1=function(x:number,y:number):number{return x+y;};

s1(19,2);
console.log(add(14,2));
console.log(s1)
let s2=(x:number,y:number)=>x+y;
var a=s2(1,2);
console.log(a)
let s3=(x:number,y:number)=>{return x+y;}
s3(1,2);
console.log(s3)
let s4=(x,y)=>x+y;
s4(1,3);
console.log(s4)
let s5=()=>console.log("fn without return")
s5();