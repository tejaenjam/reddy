function add(...x:number[]):number{
    let rew=0
    for(var i=0;i<x.length;i++)
    {
        rew+=x[i];
    }
    return rew;
}
let nums:number[]=[2,3,4,5,6]
let rew=add(...nums)
console.log(rew)