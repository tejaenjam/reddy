var fq = "aravind Reddy";
var si = 'Keshireddy';
var sq = 'hello,my name is ' + fq + 'and surname is' + si;
console.log(sq);
var sq1 = "hello,my name is " + fq + "\nmy surname is " + si;
console.log(sq1);
