/*function add(x:number,b:number,c:number=1)
{
  return x+b+c;
}
let re1=add(2,3);
let re=add(2,3,5); */
function add(x) {
    var b = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        b[_i - 1] = arguments[_i];
    }
    var re = x;
    for (var i = 0; i < b.length; i++) {
        re += b[i];
    }
    return re;
}
var re1 = add(2, 3);
var re = add(2, 3, 5, 6);
console.log(re1);
console.log(re);
