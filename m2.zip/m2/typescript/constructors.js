/*
class te {
    f;
    p;
}
var a12=new  te();
a12.f="aravind"
a12.p="reddy"
console.log(a12.f+"  "+a12.p)
*/
/*
class te {
    f;
    p;
    constructor(f:string,p:string)
    {
        this.f=f;
        this.p=p;
    }
}
var a12=new  te("ara","vind");
console.log(a12.f+"  "+a12.p)
*/
var te = /** @class */ (function () {
    function te(f, p) {
        this.f = f;
        this.p = p;
    }
    te.prototype.dis = function () {
        return this.f + " " + this.p;
    };
    return te;
}());
var a12 = new te(789, "vind");
console.log(a12.dis());
