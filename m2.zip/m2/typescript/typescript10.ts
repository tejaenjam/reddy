

/*
let l:string[]=['a','b','c']
let [q,w,e]=l
console.log(q)
console.log(w)
console.log(e)
console.log(`values  : ${q},${w},${e}`)
let ob={q1:'a',w1:'b',e1:'c'}
let {q1,w1,e1}=ob
console.log(q1)
console.log(w1)
console.log(e1)
*/

class c{
    readonly country:string="india";
    readonly name:string;
    constructor(name1:string){
        this.name=name1
    }
    sd(){
        console.log(this.name+" : "+this.country)
    }
}
let c1=new c("capg")
c1.sd();





