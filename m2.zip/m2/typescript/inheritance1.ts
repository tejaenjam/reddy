class te1 {
    private f:number;
    private p:string;
    constructor(f:number,p:string)
    {
        this.f=f;
        this.p=p;
    }
    dis()
    {
        return this.f+" "+this.p
    }
}

class te2 extends te1{
id:number;
constructor(id1:number,f1:number,p1:string)
{
super(f1,p1)
this.id=id1;
}
m1() : void{
    console.log(this.id+" "+this.dis())
}
}
var q1=new te2(12,123,"as");
console.log(q1)
q1.m1();