  /*function add(x:number,b:number,c:number=1)
{
    return x+b+c;
}
let re1=add(2,3);
let re=add(2,3,5); */
function add(x:number,...b:number[]):number
{
    let re=x;
    for(var i=0;i<b.length;i++){
        re+=b[i];
    }
    return re
}
let re1=add(2,3);
let re=add(2,3,5,6,7,8);
console.log(re1)
console.log(re)