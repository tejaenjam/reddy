let yes:boolean =true;
let no :boolean=false;
let a1:string="welcome to";
let b1:string="type";
console.log(a);