function add(a, b) {
    return a + b;
}
var sum = add(10, 20);
var sum1 = add('a', 9);
console.log("addint  " + sum);
console.log("addany  " + sum1);
function add1(a, b, c) {
    return a + b + c;
}
var sum2 = add1(10, 20);
var sum3 = add1(10, 20, 30);
console.log("addtwo  " + sum2);
console.log("addthree  " + sum3);
function add2(a, b, c, d) {
    return a + b + c + d;
}
var sum4 = add2(10, 20, 30);
var sum5 = add2(10, 20, 30, 40);
console.log("add  " + sum4);
console.log("add4  " + sum5);
