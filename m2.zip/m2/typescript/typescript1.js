var fu = function () { return 'response'; };
