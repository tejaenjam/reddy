package com.capg.service;

import com.capg.dao.AuthorDAOImpl;
import com.capg.entities.AuthorDetails;

public class AuthorServiceImpl implements AuthorService {

	AuthorDAOImpl dao = new AuthorDAOImpl();
	
	
	@Override
	public void addAuthor(AuthorDetails a) {
		// TODO Auto-generated method stub
		dao.addAuthor(a);

	}

	@Override
	public void removeAuthor(int aid) {
		// TODO Auto-generated method stub
		
		dao.removeAuthor(dao.findAuthor(aid));

	}

	@Override
	public void updateAuthor(AuthorDetails a) {
		// TODO Auto-generated method stub
		dao.updateAuthor(a);

	}

	@Override
	public AuthorDetails findAuthor(int aid) {
		// TODO Auto-generated method stub
		return dao.findAuthor(aid);
	}

}
