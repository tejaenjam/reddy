import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="qwe1")
public class EmpPojo {
	
	
@Id
@GeneratedValue(strategy=GenerationType.AUTO, generator="qwer")
@SequenceGenerator(name="qwer", sequenceName="qwertyu")


//@Column(name="eid",length=20)
private int empid;
//@Column(name="ename",length=20)
private String empname;
//@Column(name="salary",length=20)
private int empsal;




public EmpPojo(int empid, String empname, int empsal) {
	super();
	this.empid = empid;
	this.empname = empname;
	this.empsal = empsal;
}


public EmpPojo() {
	super();
}


public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getEmpname() {
	return empname;
}
public void setEmpname(String empname) {
	this.empname = empname;
}
public int getEmpsal() {
	return empsal;
}
public void setEmpsal(int empsal) {
	this.empsal = empsal;
}


}
