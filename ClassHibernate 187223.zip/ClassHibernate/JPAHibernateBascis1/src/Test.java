import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("ara");
		
		EntityManager em=emf.createEntityManager();
		
		em.getTransaction().begin();
		
		EmpPojo ep=new EmpPojo();
		ep.setEmpname("aravind");
		ep.setEmpsal(123456);
		
		
		em.persist(ep);
		
//		EmpPojo e=(EmpPojo) em.find(EmpPojo.class, 123);
//				
//	    e.setEmpname("dharma");
//	    em.merge(e);
//		
		
		em.getTransaction().commit();
		
		System.out.println("inserted");
	}

}
