package com.cap.naa;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int sid;
	
	@Column(name = "houseno", length = 20)
	private int hno;
	@Column(length = 20)
	private String colony;
	@Column(length = 20)
	private String city;
	
	
	
	
	public Address(int sid, int hno, String colony, String city) {
		super();
		this.sid = sid;
		this.hno = hno;
		this.colony = colony;
		this.city = city;
	}

	public Address() {
		super();	
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public int getHno() {
		return hno;
	}
	public void setHno(int hno) {
		this.hno = hno;
	}
	public String getColony() {
		return colony;
	}
	public void setColony(String colony) {
		this.colony = colony;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	
	
	

}
