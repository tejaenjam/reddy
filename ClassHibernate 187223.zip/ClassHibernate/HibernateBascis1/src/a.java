import java.lang.reflect.Array;
import java.util.List;

public class a {
//	int it;
//	public void i() {
//		for(int k = 0;k < 5;k++) {
//			
//		}
//	}
	public static void i(RuntimeException e) {
		System.out.println("ex");
	}
	

	public static void main(String[] args) {
		
		String h= "hello";
		if("hello" == h) {
			System.out.println("asf");
		}
	}
	
}
