package lab8;

import java.util.Scanner;

public class Exercise7 
{
	boolean m11(String s)
	{
		int l=s.length();
		char[] c=s.toCharArray();
		
		if(l>=12 && c[l-1]=='b'&& c[l-2]=='o'&& c[l-3]=='j'&& c[l-4]=='_')
		{
			return true;
		}
		
		return false;
	}
	public static void main(String[] args) 
	{
		System.out.println("username must be 8 and ends with :: _job :: extension ");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		Exercise7 e=new Exercise7();
		boolean y=e.m11(s);
		if(y==true)
		{
			System.out.println("passed / valid");
		}else
		{
			System.out.println("failed  / invalid");
		}
	}
}
