package lab8;

import java.io.File;
import java.util.Scanner;

public class Exercise4
{
	public static void main(String[] args) 
	{
		System.out.println("enter filename or location of file");
		Scanner sc=new Scanner(System.in);
		String st=sc.nextLine();
		File f=new File(st);
		System.out.println("file name  :"+f.getName());
		System.out.println("file present  :"+f.exists());
		System.out.println("file readable  :"+f.canRead());
		System.out.println("file writable   :"+f.canWrite());
		System.out.println("length of file : "+f.length());
		
	}
}
