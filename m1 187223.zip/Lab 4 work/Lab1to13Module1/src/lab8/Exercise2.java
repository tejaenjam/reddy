package lab8;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Exercise2
{
	public static void main(String[] args) throws IOException 
	{
		int i=1;
		FileWriter fw=new FileWriter("Lab8ex2.txt");
		PrintWriter pw = new PrintWriter(fw);
	    pw.println("core java");
	    pw.println("lab mipl");
	    pw.println("aravind reddy");
	    pw.flush();
	    pw.close();
	    FileReader fr=new FileReader("Lab8ex2.txt");
	    BufferedReader br=new BufferedReader(fr);
	    String t=br.readLine();
	    while(t!=null)
	    {
	    	System.out.println((i)+" "+t);
	    	t=br.readLine();
	    	i++;
	    } 
	    
	}
}
