package lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Exercise1 
{
	public static void main(String[] args)
	{
		int sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter integers");
		String s1=sc.nextLine();
		 StringTokenizer st=new StringTokenizer(s1," ");
		 System.out.println("each integer value");
		 while(st.hasMoreTokens())
		 { 
			 String s11=st.nextToken();
		 System.out.println(s11);
		sum=sum+Integer.parseInt(s11);
		 }
		 System.out.println("sum of all integers");
		 System.out.println(sum);
		sc.close();
	}
}
