package lab3;
import java.util.Scanner;


public class Exercise1
{
		int m1(int[] k,int a)
		{
			int temp = 0;
			for(int i=0;i<a;i++)
				for(int j=i+1;j<a;j++)
				{
					if(k[i]>k[j])
					{
						temp=k[i];
						k[i]=k[j];
						k[j]=temp;
					}
				}		
			return k[1]; 		
		}
	public static void main(String[] args)
	{
		System.out.println("enter the array size");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		System.out.println("enter numbers");
		int k[]=new int[a];
		for(int i=0;i<a;i++)
		{
			 k[i]=sc.nextInt();
		}
		Exercise1 w=new Exercise1();
		int t=w.m1(k,a);
		System.out.println("second largest number");
		System.out.println(t);
		sc.close();
	}
	}

