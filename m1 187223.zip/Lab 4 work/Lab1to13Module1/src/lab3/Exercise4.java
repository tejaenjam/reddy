package lab3;

import java.util.Scanner;

public class Exercise4 
{
public static void main(String[] args) 
{
Scanner sc=new Scanner(System.in);


 System.out.println("enter charecters");
 String g=sc.next();
 char[] k1=g.toCharArray();
 
 int u= k1.length;
 
 char[] k2=new char[u];
 
 System.out.println(k1);
 
 int count=0,j,k = 0;
 
 for (int i=0;i<u;i++)
 {
	k2[i]=k1[i];
		
 }
 int flag=0;
 for(int i=0;i<u;i++)
 {
	 count=0;
	 for( j=0;j<u;j++)
	 {
		 if(k1[i]==k2[j])
		 {
			count++; 
		 }
	 }
	 
	 System.out.println("value " + k1[i]+ "  " + count);
	 
 }
 
sc.close();
}
}

