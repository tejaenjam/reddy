package lab5;

import java.util.Scanner;
class Excp1 extends Exception
{  
	int b;
	Excp1(int a)
	{
	b=a;	
	}
	public String toString()
	{
		return"invalid   "+b;
	}
}

public class Exercise5
{
	void m1(int a) throws Excp1
	{
		if(a>15)
		{
			System.out.println("valid");
		}
		else
		{
			throw new Excp1(a);
		}
		
	}
	public static void main(String[] args) throws Excp1
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter age");
		int a=sc.nextInt();
		Exercise5 s=new Exercise5();
		s.m1(a);
		sc.close();
		
	}
}
