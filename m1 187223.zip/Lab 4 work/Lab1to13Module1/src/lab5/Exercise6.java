package lab5;
import java.util.Scanner;

import com.cg.eis.exception.EmployeeException;

public class Exercise6 
{
	static void  m3(int a) throws EmployeeException
	{
		if(a>=3000)
		{
			System.out.println("fair salary");
		}
		else
		{
			throw new EmployeeException();
		}
	}
	public static void main(String[] args) throws EmployeeException  
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter salary");
		int a=sc.nextInt();
		Exercise6.m3(a);
		sc.close();
	}
	
}
