package lab5;

import java.util.Scanner;

public class Exercise1
{
	public static void main(String[] args)
	{
		System.out.println("**********Traffic light**********");
		System.out.println("1. RED");
		System.out.println("2. YELLOW");
		System.out.println("3. GREEN \n");
		System.out.println("enter your choice");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		switch(n)
		{
		case 1:
			System.out.println("STOP");
			break;
		case 2:
			System.out.println("READY TO GO");
			break;
		case 3:
			System.out.println("GO");
			break;
		}
		sc.close();
	}
}
