package lab5;

import java.util.Scanner;


public class Exercise2
{
	
	int met1(int n)
	{
		if(n==0)
		{
			return 0;
		}else if(n==1)
		{
			return 1;
		}else
		{
		return met1(n-1)+met1(n-2);
		}
	}

	
	public static void main(String[] args) 
	{
		System.out.println("enter nth value");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a=0;
		int b=1;
		int temp = 0;
		Exercise2 e=new Exercise2();
		int p=e.met1(n);
		if(n==1)
		{
			System.out.println("non recursive output :  1");
		}
		while(n!=1)
		{
			temp=a+b;
			a=b;
			b=temp;
			n--;
		}
		
		System.out.println("recursive output  : "+p);
		System.out.println("non recursive output :  "+temp);
		sc.close();
	}
}

