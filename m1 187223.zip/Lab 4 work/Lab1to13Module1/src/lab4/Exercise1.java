package lab4;

import java.util.Scanner;

public class Exercise1 
{ int sum=0;
	int m1(int a)
	{
		while(a>=1)
		{
			int q=a%10;
			sum=sum+q*q*q;
			a=a/10;
		}
		return sum;
		
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int a=sc.nextInt();
		Exercise1 s=new Exercise1();
		int y=s.m1(a);
		System.out.println(y);
		sc.close();
	}
}
