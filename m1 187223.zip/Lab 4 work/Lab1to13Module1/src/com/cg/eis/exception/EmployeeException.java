package com.cg.eis.exception;

public class EmployeeException extends Exception
{
	public  EmployeeException()
	{
	}
	public String toString()
	{
		return "low salary";
	}
}
