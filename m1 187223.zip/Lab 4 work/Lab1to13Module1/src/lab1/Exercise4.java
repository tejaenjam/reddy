//lab 1 exercise 4
package lab1;

import java.util.Scanner;

public class Exercise4 
{
	 boolean m1(int n)
	{
		while(n>1)
		{
			if(n%2!=0)
			{
				return false;
			}
			n=n/2;
		}
		return true;
	}
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter number");
	int n=sc.nextInt();
	Exercise4 s=new Exercise4();
	boolean t= s.m1(n);
	if(t)
	{
		System.out.println("number is power of 2");
	}else
	{
		System.out.println("number is not power of 2");
	}
	sc.close();
	
}
}
