//lab 1 exercise 1
package lab1;

import java.util.Scanner;

public class Exercise1
{
	
	int m1(int n)
	{
		int sum=0;
		for (int i=0;i<=n;i++)
		{
			if(i%3==0 || i%5==0)
			{
				sum=sum+i;
			}
		}
		return sum;
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number n =  ");
		int n=sc.nextInt();
		Exercise1 s=new Exercise1();
		int x=s.m1(n);
		System.out.println(x);
		sc.close();
	}
}
