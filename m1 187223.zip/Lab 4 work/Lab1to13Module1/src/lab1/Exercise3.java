//lab 1 exercise 3
package lab1;
import java.util.Scanner;
public class Exercise3 
{
	boolean m1(String number)
	{  
		    int i=0;
			int h=number.length();
				int k[]=new int[h];
				while(h!=0)
				{
				k[i]=number.charAt(i);
				h--;
				i++;
				}	
		for( i=0;i<number.length()-1;i++)
		{
			if(k[i]>k[i+1])
			{	
					return false;
			}
		}
	return true ;
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number :  ");
		String  number= sc.next();
		Exercise3 s=new Exercise3();
		boolean op=s.m1(number);
		{
			if(op)
			{
				System.out.println("increasing order");
			}
			else
			{
				System.out.println("decreasing order");
			}
		}
		sc.close();
	}
}

