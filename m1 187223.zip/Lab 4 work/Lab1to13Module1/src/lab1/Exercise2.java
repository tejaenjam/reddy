//lab 1 exercise 2
package lab1;

import java.util.Scanner;

public class Exercise2
{
	int m1(int n)
	{
		int sum,sum1=0,sum2=0,k;
		for(int i=0;i<=n;i++)
		{
			sum1=sum1+i*i;
			//System.out.println(sum1);
			sum2=sum2+i;
			//System.out.println(sum2);
		}
		k=(sum2)*(sum2);
		//System.out.println(k);
		sum=sum1-k;
		return sum;
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter natural number n = ");
		int n=sc.nextInt();
		Exercise2 s=new Exercise2();
		int t=s.m1(n);
		System.out.println(t);
		sc.close();
	}
}
