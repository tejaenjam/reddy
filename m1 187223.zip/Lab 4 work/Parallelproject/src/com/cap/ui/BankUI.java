package com.cap.ui;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cap.beans.BankBean;
import com.cap.beans.TransBean;
import com.cap.dao.AccountNotFoundException;
import com.cap.dao.Balance;
import com.cap.dao.PasswordNotFoundException;
import com.cap.service.BankService;

public class BankUI 
{
	BankService b=new BankService();
	long bacc;
	String bnum1;
	int i=0;
	 Scanner sc=new Scanner(System.in);
	 void stmt()
	{
		 System.out.println("WELCOME TO XYZ BANK SERVICE \n");
		 System.out.println("************************************************* \n");
		System.out.println("enter options \n");
		System.out.println("1.create ");
		System.out.println("2.balance ");
		System.out.println("3.deposit ");
		System.out.println("4.withdrawl ");
		System.out.println("5.fund Transfer ");
		System.out.println("6.print transacion  ");
		System.out.println("7.exit  ");
	}
	
	 void choose()
	 {
		
		 while(1!=0)
		 {
			 stmt();
			 int n=sc.nextInt();
		
			 switch(n)
			 {
			 
			 case 1: 		
				 			//check name
				 			System.out.println("enter your name \n");
			 				String bname1=sc.next();
			 				String bname=namecheck(bname1);
			 				
			 				//check mobile number
				 			System.out.println("enter 10 digit  mobile number \n");
				 			String bnum2=sc.next();
				 			 bnum1=numbercheck(bnum2);
				 			 
				 			 //check dob
				 			System.out.println("enter date of birth DD:MM:YYYY \n");
				 			String bdob1 =sc.next();
				 			String bdob=dobcheck(bdob1);
				 			
				 			//check passsword
				 			System.out.println("enter password and must be 8 digits \n");
				 			String bpass1=sc.next();
				 			String bpass=checkpassword(bpass1);
				 			
				 			System.out.println("enter account type \n");
				 			String actype=sc.next();
				 			
				 			System.out.println(" Bank Branch \n ");
				 			String location=sc.next();
				 			
				 			
				 			System.out.println("minimum balance is  : 1000  \n");
				 			int bbal=1000;
				 			long bnum=Long.parseLong(bnum1);
				 			bacc=bnum+123456;
				 			BankBean bean=new BankBean(bname, bnum2, bdob, bpass, bbal, bnum, location, actype);
				 			Long accNum=b.createAccount(bean);
				 			if(accNum>0)
				 			{
				 			System.out.println("Account Created with !"+accNum);
				 			
				 			}
				 		  break;
				 		  
				 			
			 case 2:	  System.out.println("enter your account number \n");
			 			  long account1=sc.nextLong();
			 			  System.out.println("enter password \n");
			 			  String password1=sc.next();
			 			  try {
			 				  int a1= b.showbalance(account1,password1);
			 				  System.out.println("Available Balance  : "+a1);
		 				  	  }
			 			  catch(AccountNotFoundException exception)
			 			  		{
			 				  System.out.println(exception.getMessage());
			 			  		}
			 			  catch(PasswordNotFoundException pa)
			 			  		{
			 				  System.out.println(pa.getMessage());
			 			  	}	
			 			  break;
			 			  
			        
			 case 3:	 System.out.println("enter your account number \n");
			 			 long account2=sc.nextLong();
			 			 
			 			 while(1!=0) {                                                                   //account 
				 			  boolean  val21=b.validation2(account2); 
				 			  if(val21)
				 			  {			
				 				  System.out.println("account number is correct \n");
				 				  break;
				 			  }else
				 			  {
				 				  System.out.println("enter valid account number \n");
				 				 
					 			  account2=sc.nextLong(); 
				 			  }
				 			  }
			 			 System.out.println("enter password \n");
			 			 String password2=sc.next();
			 			 
			 			while(1!=0)                                                                       //password 
			 			{
			 			boolean  val111=b.validation(account2,password2);
		                if(val111)
		                {
		                	 System.out.println(" password is correct \n");
		                	 break;
		                	 
				         }	else
				         {
				        	 System.out.println("enter valid  password \n");
				        	 password2=sc.next();
				        	 
				         }
			 			}
			 			 System.out.println("enter deposit amount \n");
		 				 int dep1=sc.nextInt();
		 				 int a11=b.deposit(account2,password2,dep1);
		 				 System.out.println("balance after deposit \n");
		 				 System.out.println(a11);
			 			 break;
			 			 
			 case 4:  	System.out.println("enter your account number \n");
			 			long account3=sc.nextLong();
			 			
			 			 while(1!=0) {                                                                   //account 
				 			  boolean  val21=b.validation2(account3); 
				 			  if(val21)
				 			  {			
				 				  System.out.println("account number is correct \n");
				 				  break;
				 			  }else
				 			  {
				 				  System.out.println("enter valid account number \n");
				 				 
					 			  account3=sc.nextLong(); 
				 			  }
				 			  }
			 			
			 			System.out.println("enter password \n");
			 			String password3=sc.next();
			 			
			 			while(1!=0)                                                                       //password 
			 			{
			 			boolean  val111=b.validation(account3,password3);
		                if(val111)
		                {
		                	 System.out.println(" password is correct \n");
		                	 break;
		                	 
				         }	else
				         {
				        	 System.out.println("enter valid  password \n");
				        	 password3=sc.next();
				        	 
				         }
			 			}
			 			
			 			 System.out.println("enter withdrawl amount \n");
	                	 int dep3=sc.nextInt();
	                	
	                	 int a111=b.withdrawl(account3,password3,dep3);
	                	 boolean i1=b.validbal(dep3);
	                	 if(i1)
	                	 {
	                		 System.out.println("insufficient balance \n");
	                	 }else
	                	 { 
	                	 System.out.println("balance after withdrawl \n");
	                	 System.out.println(a111);
	                	 }
			 			 break;
			 			
			 case 5: 	System.out.println("enter account 1 to send funds \n");
			 			long account31=sc.nextLong(); 
			 			
			 			
			 			
			 			System.out.println("enter password \n");
			 			String password31=sc.next();
			 			
			 			
			 			System.out.println("enter account 2 to receive funds \n");
			 			long account32=sc.nextLong(); 
			 			
			 			
			 			System.out.println("enter fund amount \n" );
		 				int k1=sc.nextInt();
		 				
		 				try
		 				{
		 				int ba12= b.fund(account31,account32,password31,k1);
		 				System.out.println("account 1  balance \n");
		 				System.out.println(ba12);
		 				}
		 				catch(AccountNotFoundException ae)
		 				{
		 					System.out.println(ae.getMessage());
		 				}
		 				catch(PasswordNotFoundException pa)
		 				{
		 					System.out.println(pa.getMessage());
		 				}catch(Balance de)
		 				{
		 					System.out.println("invalid account number \n");
		 				}
			 			break;
			 			
			 case 6:   System.out.println("print  transaction \n");
			 		   System.out.println("enter account number \n");
			 		   long account33=sc.nextLong();
			 		   
			 		  while(1!=0) {                                                                   //account 
			 			  boolean  val21=b.validation2(account33); 
			 			  if(val21)
			 			  {			
			 				  System.out.println("account number is correct \n");
			 				  break;
			 			  }else
			 			  {
			 				  System.out.println("enter valid account number \n");
			 				 
				 			  account31=sc.nextLong(); 
			 			  }
			 			  }
			 		  	System.out.println("enter password \n");
			 			String password34=sc.next();
			 			
			 			while(1!=0)                                                                  //password 
			 			{
			 				boolean  val111=b.validation(account33,password34);
			 			
			 			if(val111)
			 			{
			 				
			 				System.out.println("password is correct \n");                     
			 				break;
			 			}	else
			 			{
			 				System.out.println("enter valid  password \n");
			 				password31=sc.next();
			 			}
			 			}
			 		  
			 		  		List listui=b.transactionui();
			 		  		System.out.println(listui);
			 		  		
			 case 7:   exit();	
			 
			 }
		 }
	 }
	 
	 
	 
	private void exit()
	{	
		 stmt();
	}

	private String checkpassword(String bpass1) 
	{
		// TODO Auto-generated method stub
		while(1!=0)
		{
		if(bpass1.length()<8)
		{
			System.out.println("password is invalid and must be 8 digits \n");
			bpass1=sc.next();
			
			
		}else
		{
			System.out.println("password is correct \n");
			return bpass1;
		}
		}
	}

	//check date of birth
	private String dobcheck(String bdob1)
	{
		// TODO Auto-generated method stub
		while (1!=0)
		{
		if(bdob1.length()==8 && bdob1.matches("[0-9]*" ))
			{
			System.out.println("dob is correct \n");
			return bdob1;
			}else
			{
			System.out.println("enter valid date of birth \n");
			bdob1=sc.next();
			
			}	
		}
	}
	
	//check mobile  number
	 String numbercheck(String bnum2)
	{
		// TODO Auto-generated method stub
		 while(1!=0)
		 {
		if((bnum2.length())==10 && bnum2.matches("[6-9][0-9]{9}"))
				{
					System.out.println("number is correct \n");
					return bnum2;
				}else
				{
					System.out.println("enter valid mobile number \n");
					bnum2=sc.next();
					
				}
			
		 }
	}
	
	//check name
	String namecheck(String bname1)
	{
		while(true)
		{
		if(Pattern.matches("[A-Z][A-Za-z( )(.)]*", bname1))
		{
			System.out.println("name correct \n");
			return bname1;
		} else
		{
			System.out.println("enter valid name \n");
			bname1=sc.next();	
		}
		}
	}

	
	public static void main(String[] args) 
	{

		BankUI a1=new BankUI();
		a1.choose();
	}
}
