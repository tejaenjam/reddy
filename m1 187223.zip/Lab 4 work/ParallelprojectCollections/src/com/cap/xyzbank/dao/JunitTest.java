package com.cap.xyzbank.dao;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

import com.cap.xyzbank.beans.BankBean;


public class JunitTest {
	
	static BankDaoI dao = new BankDao();
	static BankBean bean = new BankBean("aravind","7093117585" , "22061197", "aravind123", 1000, 879111638, "chennai", "savings");
	static {
		long a=dao.createAccount1(bean);
	}
	
	@Test
	public void TestCreateAccount1()
	{
		BankBean bean = new BankBean("aravind","7093117585" , "22061197", "aravind123", 1000, 879111639, "chennai", "savings");
		long a=dao.createAccount1(bean);
		 assertEquals(879111639, a);	
	}
	
	
	@Test
	public void TestShowbalace1()
	{
		int a=dao.showbalace1(879111638, "aravind123");
		 assertEquals(1000, a);
	}
	
	
	@Test
	public void TestDeposit1()
	{
		int a=dao.deposit1(879111638, "aravind123",200);
		 assertEquals(1200, a);
		 ((BankDao)dao).getHm().get(879111638L).setBbal(1000);
	}
	
	
	@Test
	public void TestWithdrawl1()
	{
		int a=dao.withdrawl1(879111638, "aravind123",200);
		 assertEquals(800, a);
		 ((BankDao)dao).getHm().get(879111638L).setBbal(1000);
	}

}

