package com.capgemini.hotel.dao;

public class IDNotFoundException extends RuntimeException {
	public IDNotFoundException(String s)
	{
	super(s);
	}
}
