package com.cap.xyzbank.dao;

public class Balance extends RuntimeException
{
public Balance()
{
	// TODO Auto-generated constructor stub
	super();
	
}
}
