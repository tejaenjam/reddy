import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServicelayerService {

  router:Router;
  ht:HttpClient;
  constructor( ht:HttpClient,router:Router) { this.ht=ht;this.router=router
  }

  createaccount(newcustomername: any, newphonenumber: any, newdateofbirth: any, newpassword: any, newlocation: any, newaccounttype: any, newbalance: any):Observable<any>{

    let jsonobj={
      "bname":newcustomername,
      "bnum2":newphonenumber,
      "bdob":newdateofbirth,
      "bpass":newpassword,
       "bbal":newbalance,
      "actype":newaccounttype,
      "location":newlocation
    }
    let url="http://localhost:2020/xyzbank/adddetails";
    return this.ht.post(url,jsonobj);
    
  }
  
  showbalance(accountnumber: any, password: any):Observable<any>{
          let url="http://localhost:2020/xyzbank/showbalance/"+accountnumber+"/"+password;
        return  this.ht.get(url);
       
  }

deposit(accountnumber: any, password: any, depositbalance: any): Observable<any>
   {
      let json={
        "bacc":accountnumber,
        "bpass":password,
        "bbal":depositbalance
      }
    let url="http://localhost:2020/xyzbank/deposit";
  return  this.ht.put(url,json);
 
   }




withdraw(accountnumber: any, password: any, withdrawbalance: any): Observable<any> {
  let json={
    "bacc":accountnumber,
    "bpass":password,
    "bbal":withdrawbalance
  }
  let url="http://localhost:2020/xyzbank/withdraw";
  // +"/"+password
// return  this.ht.put(url,json);

return this.ht.put(url,json);
 
}


fundtransfer(accountnumber1: number, password1: string, accountnumber2: number, fundtransferamount: number) :Observable<any>
{
  let url="http://localhost:2020/xyzbank/fundtransfer/"+accountnumber1+"/"+password1+"/"+accountnumber2+"/"+fundtransferamount;
  // +"/"+password
// return  this.ht.put(url,json);
return this.ht.get(url)
}


transaction(accountnumber: any, password: any): Observable<any> {
  let url="http://localhost:2020/xyzbank/printtransaction/"+accountnumber+"/"+password;
  // +"/"+password
// return  this.ht.put(url,json);
return this.ht.get(url)
}

 }

