package com.cap.service;

import java.util.List;

import com.cap.entity.BankEntity;
import com.cap.entity.TransactionEntity;
import com.cap.exception.DataNotFoundException;

public interface IBankService {
	public long Creation(BankEntity bankbean);
	public int showbalance(long accountnumber,String password) throws DataNotFoundException ;
	public int deposit(long accountnumber, int depositamount,String password) throws DataNotFoundException;
	public int withdraw(long accountnumber, int withdrawamount,String password) throws DataNotFoundException;
	public int fundtransfer(long accountnumber1, long accountnumber2, int fundamount,String password) throws DataNotFoundException;
	public List<TransactionEntity> printtransaction(long accountnumber,String password) throws DataNotFoundException;

}
