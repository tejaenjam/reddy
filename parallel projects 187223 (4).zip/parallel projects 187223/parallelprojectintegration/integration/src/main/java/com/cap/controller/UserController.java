package com.cap.controller;

import java.io.Console;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entity.BankEntity;
import com.cap.entity.TransactionEntity;
import com.cap.exception.DataNotFoundException;
import com.cap.service.IBankService;

@RestController
@RequestMapping("/xyzbank")
@CrossOrigin(origins = "http://localhost:4200")

public class UserController {
	@Autowired
	IBankService bankserviceobject;

	@PostMapping(value = "/adddetails")
	long Creation(@Valid @RequestBody  BankEntity bankbean) {
		return  bankserviceobject.Creation(bankbean);
	}
	
	@GetMapping
	@RequestMapping("/showbalance/{accountnumber}/{password}")
	int showbalance(@PathVariable long accountnumber,@PathVariable String password) throws DataNotFoundException
	{
		return  bankserviceobject.showbalance(accountnumber,password);
	}
	
	@PutMapping("/deposit")
	int deposit(@RequestBody final BankEntity bankbean) throws DataNotFoundException
	{
		
		Long accountnumber = bankbean.getBacc();
		int depositamount = bankbean.getBbal();
		String password =bankbean.getBpass();
		System.out.println("deposit 1  :"+bankbean.getBbal());
		return bankserviceobject.deposit(accountnumber,depositamount,password);
		
	}
	@PutMapping("/withdraw")
	int withdraw(@RequestBody final BankEntity bankbean) throws DataNotFoundException
	{
		Long accountnumber = bankbean.getBacc();
		int withdrawamount = bankbean.getBbal();
		String password =bankbean.getBpass();
		return bankserviceobject.withdraw(accountnumber,withdrawamount,password);
		
	}
	@PutMapping
	@RequestMapping("/fundtransfer/{accountnumber1}/{password}/{accountnumber2}/{fundamount}")
	int fundtransfer(@PathVariable long accountnumber1,@PathVariable String password,@PathVariable long accountnumber2,@PathVariable int fundamount) throws DataNotFoundException
	{
		return bankserviceobject.fundtransfer(accountnumber1,accountnumber2,fundamount,password);
		
	}
	
	@GetMapping("/printtransaction/{accountnumber}/{password}")
	List<TransactionEntity> printtransaction(@PathVariable long accountnumber,@PathVariable String password) throws DataNotFoundException
	{
		return bankserviceobject.printtransaction(accountnumber,password);
		
	}
}


//{"bname":"Aravind",
//"bnum2":"7093117585",
//"bdob":"22/06/1997",
//"bpass":"aravind123",
// "bbal":1200,
//"actype":"Savings",
//"location":"Hyderabad"}