import { Component, OnInit } from '@angular/core';
import { ServicelayerService } from 'src/app/servicelayer.service';

@Component({
  selector: 'app-funds',
  templateUrl: './funds.component.html',
  styleUrls: ['./funds.component.css']
})
export class FundsComponent implements OnInit {
servicelayer:ServicelayerService;
  constructor(servicelayer:ServicelayerService) {this.servicelayer=servicelayer; }

  fundtransfer(data:any)
  {
this.servicelayer.fundtransfer(data.accountnumber1,data.password1,data.accountnumber2,data.fundtransferamount);
  }

  ngOnInit() {
  }

}
