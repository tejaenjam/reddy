import { Component, OnInit } from '@angular/core';
import { ServicelayerService } from 'src/app/servicelayer.service';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
 

  servicelayer:ServicelayerService;
  constructor(servicelayer:ServicelayerService) {this.servicelayer= servicelayer}

  transaction(data:any)
  {
    this.servicelayer.transaction(data.accountnumber,data.password)

  }
  ngOnInit() {
  }

}
