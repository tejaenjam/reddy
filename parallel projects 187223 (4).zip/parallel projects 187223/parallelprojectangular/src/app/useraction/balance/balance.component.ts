import { Component, OnInit } from '@angular/core';
import { ServicelayerService } from 'src/app/servicelayer.service';

@Component({
  selector: 'app-balance',
  templateUrl: './balance.component.html',
  styleUrls: ['./balance.component.css']
})
export class BalanceComponent implements OnInit {
servicelayer:ServicelayerService;
  constructor(servicelayer:ServicelayerService) {this.servicelayer= servicelayer}

  showbalance(data:any)
  {
    this.servicelayer.showbalance(data.accountnumber,data.password)

  }
  ngOnInit() {
  }

}
