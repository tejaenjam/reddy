import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServicelayerService, BankBean } from '../servicelayer.service';
import { empty } from 'rxjs';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  router:Router;
  servicelayer:ServicelayerService;
  constructor(router:Router,servicelayer:ServicelayerService) {
     this.router=router;
    this.servicelayer=servicelayer;
  }

  bankbean:BankBean;   
  create(data:any){
    if((data.newcustomername=="") || (data.newphonenumber=="" ) || (data.newdateofbirth=="") || (data.newpassword=="") || (data.newlocation=="") ||(data.newaccounttype=="") ||(data.newbalance== "")){
      alert("no blank spaces")
    }
    else{
   var customeraccountnumber=data.newphonenumber+96587496325;
  this.bankbean=new BankBean(data.newcustomername,data.newphonenumber,data.newdateofbirth,data.newpassword,data.newlocation,data.newaccounttype,data.newbalance,customeraccountnumber,"\n"); 
  this.servicelayer.createaccount(this.bankbean); 
  console.log(this.bankbean);
    }
  // alert("ACCOUNT NUMBER :"+customeraccountnumber)
  // if(true)
  // {
  // this.router.navigate(['useraction']);
  // } 
}
  ngOnInit() {
  }

}
