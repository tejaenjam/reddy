package com.cap.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

@Entity
@Table(name="capemp123")
public class entity {
@Id

private Integer id;
@NotBlank (message = "Name is mandatory")
private String name;

@NotNull
private Integer fees;

private Long duration;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Integer getFees() {
	return fees;
}
public void setFees(Integer fees) {
	this.fees = fees;
}
public Long getDuration() {
	return duration;
}
public void setDuration(Long duration) {
	this.duration = duration;
}





}
