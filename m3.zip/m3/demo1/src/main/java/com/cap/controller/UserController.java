package com.cap.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.beans.entity;
import com.cap.service.IService;


@RestController
@RequestMapping("/aravind")
public class UserController {
	
	@Autowired
	IService service;
	
	@PostMapping(value="/addDetails")
	public List<entity> AddMethod(@Valid @RequestBody final entity beanobj) {
		
		ArrayList<entity> ara=new ArrayList<>();
		ara.add(beanobj);
	   		 return service.AddMethod(ara);
	        }
		
       
	
//	   @Query("from Product where name=?1")
//	    List<Product> findByName1(String name);
//
//	 
//
//	    @Query("select a from Product a where price between ?1 and ?2")
//	    List<Product> findByPrice(String first, String second)
	
	
	
	
//	@PostMapping(value="/addDetails")
//	public entity AddMethod(@Valid @RequestBody final entity beanobj,BindingResult bindingResult) {
//	       if(bindingResult.hasErrors()) {
//	    	   System.out.println("invalid data");
//	         return null;
//	        }
//	        else {
//	        	service.AddMethod(beanobj);
//	   		 return beanobj;
//	        }
//		
//       
//	}
	
	
	
	
	
	@PutMapping(value="/updateDetails/{id}")
	public List<entity> updateMethod(@PathVariable int id,@RequestBody entity beanobj){
		
		return  service.updateMethod(id,beanobj);
	}
	
	@GetMapping("/find/{id}")
	public entity getdata(@PathVariable final int id) {
		return service.getdata(id);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deletedata(@PathVariable final int id) {
		return service.deletedata(id);
		
	}
	
	
	
	

}
