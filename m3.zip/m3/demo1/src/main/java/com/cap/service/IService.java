package com.cap.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.beans.entity;
import com.cap.dao.Dao;


@Service
@Transactional
public class IService {
	
	
@Autowired
Dao dao;


	public List<entity> AddMethod(@Valid ArrayList<entity> ara) {
			for(entity e:ara){
				dao.save(e);
			}
			return dao.findAll();	        
		}
	
	
	public List<entity> updateMethod(int id, entity beanobj) {
		
		Optional<entity> opt= dao.findById(id);
		if(opt.isPresent())
		{
			
			
			entity bean=opt.get();
			
//			int a=bean.getFees();
//			int b=a*4;
//			bean.setFees(b);
			
			bean.setFees(beanobj.getFees());
			bean.setName(beanobj.getName());
			dao.save(bean);
			return dao.findAll();
		}else {
			return null;
		}
		}



	public entity getdata(int id) {
		return dao.findById(id).get();
	}



	public String deletedata(int id) {
		dao.deleteById(id);
		Optional<entity> opt= dao.findById(id);
		if(opt.isPresent())
		{
			return "data is not deleted";
		}else {
			return "data is deleted";
		}
		
		
	}
	
	

}
