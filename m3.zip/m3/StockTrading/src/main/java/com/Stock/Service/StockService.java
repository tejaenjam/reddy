package com.Stock.Service;

import java.util.List;

import com.Stock.entity.Stock;

public interface StockService {
	public int calculateOrder(Stock bean);
	public List<Stock> updateMethod(int id, Stock bean);
	public Stock finddatabyid(int id);
	public List<Stock> finddata();
	public String deletedata(int id);
}
