package com.Stock.Service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.Stock.Dao.StockRepo;
import com.Stock.entity.Stock;


@Service
public class ServiceImpl {
@Autowired
StockRepo dao;
double brokerage;
	
	public int calculateOrder(Stock bean) {
		System.out.println("bb");
			
		double amount =bean.getPrice()+bean.getQuantity();
		if(bean.getQuantity()>100)
		{
			 brokerage=((0.3)/100)*amount;
		}else {
			 brokerage=((0.5)/100)*amount;
		}
		
		bean.setBrokerage(brokerage);
		bean.setAmount(amount);
		dao.save(bean);
		int idnumber=bean.getId();
	
		return idnumber;
	}

	

	public List<Stock> updateMethod(int id, Stock bean) {
		
		Optional<Stock> opt= dao.findById(id);
		if(opt.isPresent())
		{
			Stock bean1=opt.get();
			bean1.setPrice(bean.getPrice());
			bean1.setQuantity(bean.getQuantity());
			dao.save(bean1);
			return dao.findAll();
		}else {
			return null;
		}
	}

	
	
	
	public Stock finddatabyid(int id) {
		return dao.findById(id).get();
	}


	public List<Stock> finddata() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}



	public String deletedata(int id) {
		dao.deleteById(id);
		Optional<Stock> opt= dao.findById(id);
		if(opt.isPresent())
		{
			return "data is not deleted in table";
		}else {
			return "data is deleted in table";
		}
		
		
	}
	

}
