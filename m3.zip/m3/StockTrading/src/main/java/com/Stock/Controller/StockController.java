package com.Stock.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.Stock.Service.ServiceImpl;
import com.Stock.entity.Stock;


@RestController					
public class StockController {
	@Autowired
    ServiceImpl service;
	@PostMapping(value="/addDetails")
	//inserting the data by annotation
	public int AddMethod(  @RequestBody  Stock bean) {
		System.out.println("aaa");
	   		 return service.calculateOrder(bean);
	        }
	
	@PutMapping(value="/updateDetails/{id}")							//updating the data by using id 
	public List<Stock> updateMethod(@PathVariable int id,@RequestBody Stock bean){
		
		return  service.updateMethod(id,bean);
	}
	
	@GetMapping("/finddata")										//get all the details
	public List<Stock> finddata() {						
		return service.finddata();
	}
	@GetMapping("/find/{id}")										//get by id
	public Stock finddatabyid(@PathVariable final int id) {
		return service.finddatabyid(id);
	}
	@DeleteMapping("/deletedata/{id}")								//delete the data by id
	public String deletedata(@PathVariable final int id) {
		return service.deletedata(id);
		
	}
	
	

}
