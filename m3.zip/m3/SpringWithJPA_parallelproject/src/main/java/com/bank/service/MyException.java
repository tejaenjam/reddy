package com.bank.service;

public class MyException  extends Exception{
		private static final long serialVersionUID = 1L;
		String s1;
		MyException(String s)
		{
			 s1=s;
		}
		public String toString()
		{
			return (s1);
		}
	

}
