package com.bank.entities;

import javax.persistence.*;


@Entity
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TransId")
	private long transId;
	@Column(name = "InitialAcc")
	private long baccInitial;
	@Column(name = "FinalAcc")
	private int baccFinal;  //initialbalance
	@Column(name = "TransType")
	private String transMetd;
	@Column(name = "Amountused")
	private int transBal;
	

	

	public Transaction(long transId, long baccInitial, int baccFinal, String transMetd, int transBal
			) {
		super();
		this.transId = transId;
		this.baccInitial = baccInitial;
		this.baccFinal = baccFinal;
		this.transMetd = transMetd;
		this.transBal = transBal;
		
	}

	public Transaction() {
		super();
	}



	public int getBaccFinal() {
		return baccFinal;
	}

	public void setBaccFinal(int baccFinal) {
		this.baccFinal = baccFinal;
	}

	public long getTransId() {
		return transId;
	}

	public void setTransId(long transId) {
		this.transId = transId;
	}

	public long getBaccInitial() {
		return baccInitial;
	}

	public void setBaccInitial(long baccInitial) {
		this.baccInitial = baccInitial;
	}

	public String getTransMetd() {
		return transMetd;
	}

	public void setTransMetd(String transMetd) {
		this.transMetd = transMetd;
	}

	public int getTransBal() {
		return transBal;
	}

	public void setTransBal(int transBal) {
		this.transBal = transBal;
	}


	@ManyToOne
	private Bank bank;

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}
}
