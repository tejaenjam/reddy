package com.bank.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bank.entities.Bank;
import com.bank.entities.Transaction;
import com.bank.service.MyException;

@Repository("bankDAO")
@Transactional
public class BankDAO implements BankDaoI {

	boolean b ;ArrayList<Transaction> te;
	@PersistenceContext
	private EntityManager entityManager;

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	
	@Override
	public boolean createAccount(Bank bank) {
		entityManager.persist(bank);
		return true;

	}

	@Override
	public int showBalance(long accountNo) {
		int balance = 0;
		Bank bank = entityManager.find(Bank.class, accountNo);
		balance = bank.getBalance();
		return balance;
	}

	@Override
	public int depositBalance(long accountNo, int deposit) {
		Bank bank = entityManager.find(Bank.class, accountNo);
		int bal = bank.getBalance();
		int bal1 = bal + deposit;
		System.out.println("getting balance"+bal);
		bank.setBalance(bal1);
		Transaction tran = new Transaction();
		tran.setBaccInitial(accountNo);
		tran.setBaccFinal(bal);
		tran.setTransMetd("deposit");
		tran.setTransBal(bal1);
		tran.setBank(bank);
		entityManager.persist(tran);
		entityManager.merge(bank);
		return bal1;
	}

	@Override
	public int withdrawAmount(long accountNo, int withdraw) {
		Bank bank = entityManager.find(Bank.class, accountNo);
		int bal = bank.getBalance();
		
		int bal1 = bal - withdraw;
		if(bal1>=0)
		{
		bank.setBalance(bal1);
		Transaction tran = new Transaction();
		tran.setBaccInitial(accountNo);
		tran.setBaccFinal(bal);
		tran.setTransBal(bal1);
		tran.setTransMetd("withdraw");
		tran.setBank(bank);
		entityManager.persist(tran);
		entityManager.merge(bank);

		return bal1;
		}else {
			throw new MyException("enter correct data");
		}

	}

	@Override
	public boolean fundTransfer(long accountNo, long accno, int amount) {
		boolean b = false;
		Bank bank = entityManager.find(Bank.class, accountNo);
		Bank bank1 = entityManager.find(Bank.class, accno);
		if (bank.getBalance() <= amount) {
			b = false;
		} else {
			int bal = bank.getBalance();
			int bal1 = bank1.getBalance();
			int bal2 = bal1 + amount;
			int bal3 = bal - amount;
			
			bank1.setBalance(bal2);
			Transaction tran = new Transaction();
			tran.setBaccInitial(accno);
			tran.setBaccFinal(bal);
			tran.setTransMetd("fundtransfer");
			tran.setTransBal(bal3);
			tran.setBank(bank1);
			entityManager.persist(tran);
			
			bank.setBalance(bal3);
			Transaction tran1 = new Transaction();
			tran1.setBaccInitial(accountNo);
			tran1.setBaccFinal(bal1);
			tran.setTransMetd("fundtransfer");
			tran.setTransBal(bal2);
			tran.setBank(bank);
			entityManager.persist(tran1);
			b = true;
		}
		return b;
	}

	@Override
	public boolean validateAccount(long accountNo, String password) {
	
		Bank bank1 = entityManager.find(Bank.class, accountNo);
		if(bank1==null)
		{
			b=false;
		}
		else
		{
	   String pass = bank1.getPassword();
		System.out.println(pass);
		if (password.equals(pass)) {
			b = true;
		}
		else
		{
			b =false;
		}
		}
		return b;
	}

	@Override
	public List<Transaction> getTransactions(long accountNo) {
		Bank bank = entityManager.find(Bank.class, new Long(accountNo));
		if (bank == null) {
			throw new MyException("enter valid account number ");
		} else {
			TypedQuery<Transaction> trans = entityManager
					.createQuery("SELECT  t from Transaction as t where t.bank=:bank", Transaction.class);
			trans.setParameter("bank", bank);
			te = (ArrayList<Transaction>) trans.getResultList();
			return te;
		}
	}

	
}