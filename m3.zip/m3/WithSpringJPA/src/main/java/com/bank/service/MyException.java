package com.bank.service;

public class MyException extends RuntimeException{
	public MyException(String s) {
		super(s);
	}
}
