package com.plp.sorting.util;

public enum Rating {
	Poor, Okay, Good, VeryGood, Excellent;
}