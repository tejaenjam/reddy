package com.plp.sorting.controller;

public class UserException extends RuntimeException {
	public UserException(String s) {
		super(s);
	}

	public UserException() {
		super();
	}

}
