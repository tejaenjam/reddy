package com.plp.sorting.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.plp.sorting.bean.Category;
import com.plp.sorting.bean.Product;
import com.plp.sorting.service.IServiceInfo;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {
	@Autowired
	IServiceInfo serviceObj;

	@PostMapping(value = "/productdata")
	long productData(@RequestBody Product product) {
		return serviceObj.productData(product);
//		 {
//			 "productName":"watch",
//			 "productDescription":"sonota",
//			 "productQuantity":50,
//			 "productPrice":1400,
//			 "productDiscount":20,
//			 "productViews":250,
//			 "productRating":5,
//			 "category":{"categoryId":20000}
//			 }
	}

	@PostMapping(value = "/categorydata")
	long categoryData(@RequestBody Category category) {
		return serviceObj.catagoryData(category);
		// {
		// "categoryGender":"male",
		// "categoryType":"thing"
		// }
	}

	@GetMapping(value = "/sortbypriceAsc/{productname}")
	List<Product> sortByPriceAscending(@PathVariable String productname) {
		return serviceObj.sortByPriceAscending(productname);
	}

	@GetMapping(value = "/sortbypricedesc/{productname}")
	List<Product> sortByPriceDescending(@PathVariable String productname) {
		return serviceObj.sortByPriceDescending(productname);
	}

	@GetMapping(value = "/searchbygender/{item}")
	List<Product> searchByGender(@PathVariable String item) {
		return serviceObj.searchByGender(item);
	}

	@GetMapping(value = "/searchbytype/{item}")
	List<Product> searchByType(@PathVariable String item) {
		return serviceObj.searchByType(item);
	}

	@GetMapping(value = "/pricerange/{productname}/{minprice}/{maxprice}")
	List<Product> priceRange(@PathVariable String productname, @PathVariable double minprice,
			@PathVariable double maxprice) {
		return serviceObj.priceRange(productname, minprice, maxprice);
	}

	@GetMapping(value = "/sortbyviews/{productname}")
	List<Product> sortByViews(@PathVariable String productname) {
		return serviceObj.sortByViews(productname);
	}

	@GetMapping(value = "/sortbyrating/{productname}")
	List<Product> sortByRating(@PathVariable String productname) {
		return serviceObj.sortByRating(productname);
	}

}
