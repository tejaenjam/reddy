package com.plp.sorting.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ExceptionHandling {
	@ExceptionHandler(UserException.class)
	public ResponseEntity<String> handleException(UserException ex) {
		return new ResponseEntity<String>("Error : " +ex.getMessage(), HttpStatus.CONFLICT);
	}
}
