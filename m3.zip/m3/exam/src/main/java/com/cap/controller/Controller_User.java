package com.cap.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entity.Stock;
import com.cap.exception.StockException;
import com.cap.service.StockService;

@RestController
@RequestMapping("/sharetrading")

public class Controller_User { // class is implementing
	@Autowired // calling object
	StockService serviceobj; // indirect object Creation

	@PostMapping(value = "/addDetails") // annotation is called
	public int Adddata(@Valid @RequestBody final Stock bean) throws StockException { // method is implementing
		return serviceobj.calculateOrder(bean); // calling method in service
	}

	@PutMapping(value = "/updateDetails/{id}") // put annotation is implementing
	public Stock updatedata(@PathVariable int id, @Valid @RequestBody Stock bean) throws StockException { // method is
																											// implementing
		return serviceobj.updatedata(id, bean); // calling method in service
	}

	@GetMapping("/finddatainfo") // get annotation is called
	public List<Stock> finddatainfo() throws StockException { // method is implementing
		return serviceobj.finddata(); // service method is called
	}

	@DeleteMapping("/deletedatabyid/{id}") // delete annotation is used
	public String deletedatainfobyid(@PathVariable int id) throws StockException { // method is implementing
		return serviceobj.deletedatainfobyid(id); // service method is called

	}

	@GetMapping("/finddatainfobyid/{id}") // get annotation is used
	public Stock finddatainfobyid(@PathVariable int id) throws StockException { // method is implementing
		return serviceobj.finddatainfobyid(id); // service method is called
	}

}
