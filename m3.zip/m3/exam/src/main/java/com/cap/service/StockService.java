package com.cap.service;

import java.util.List;

import com.cap.entity.Stock;
import com.cap.exception.StockException;

//inteface of service class which contains method declaration
public interface StockService {
	public int calculateOrder(Stock bean) throws StockException;

	public Stock updatedata(int id, Stock bean) throws StockException;

	public List<Stock> finddata() throws StockException;

	public String deletedatainfobyid(int id) throws StockException;

	public Stock finddatainfobyid(int id) throws StockException;
}
