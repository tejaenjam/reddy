package com.cap.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

//Exception handling class
@ControllerAdvice
public class StockExceptionHandler {

	@ExceptionHandler(StockException.class) // ExceptionHandler annotation is used
	public ResponseEntity<String> handleException(Exception ex) {
		return new ResponseEntity<String>("Error : " + ex.getMessage(), HttpStatus.CONFLICT);

	}
}
