package com.cap.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.StockRepo;
import com.cap.entity.Stock;
import com.cap.exception.StockException;

//Service method is used
@Service
@Transactional // to begin and commit
public class ServiceImp implements StockService { // service class implements interface stockservice
	@Autowired
	StockRepo daoobj; // indirect object creation
	double brokerage;
	int idnumber;

	public int calculateOrder(Stock bean) throws StockException { // method implementation

		try {
			double amount = bean.getPrice()* bean.getQuantity();
			if (bean.getQuantity() > 100) // if statement is executing
			{
				brokerage = ((0.3) / 100) * amount;
			} else {
				brokerage = ((0.5) / 100) * amount;
			}
			/* data is setting or adding in db */
			bean.setBrokerage(brokerage);
			bean.setAmount(amount);
			daoobj.save(bean); // data is saved in database
			idnumber = bean.getId();
			System.out.println(bean);
		} catch (Exception ex) // exception is catched
		{
			throw new StockException(ex.getMessage());
		}
		return idnumber; // id is returned
	}

	public Stock updatedata(int id, Stock bean) throws StockException { // method is implementing
		try {
			Optional<Stock> optional = daoobj.findById(id); // optional is used
			if (optional.isPresent()) // if statement is implementing
			{
				Stock bean1 = optional.get();
				bean1.setPrice(bean.getPrice());
				bean1.setQuantity(bean.getQuantity());

				double amount = bean1.getPrice() * bean1.getQuantity();
				if (bean1.getQuantity() > 100) // if statement is implementing
				{
					brokerage = ((0.3) / 100) * amount;
				} else {
					brokerage = ((0.5) / 100) * amount;
				}
				/* data is setting or adding in db */
				bean1.setBrokerage(brokerage);
				bean1.setAmount(amount);
				daoobj.save(bean1); // data is saved in database
				return bean1;
			} else {
				return null;
			}
		} catch (Exception ex) // exception is catched
		{
			throw new StockException(ex.getMessage());
		}

	}

	public List<Stock> finddata() throws StockException { // method is implementing
		// TODO Auto-generated method stub
		try {
			return daoobj.findAll();
		} catch (Exception ex) // exception is catched
		{
			throw new StockException(ex.getMessage());
		}
	}

	public String deletedatainfobyid(int id) throws StockException { // method is implementing
		try {
			daoobj.deleteById(id);
			Optional<Stock> optional = daoobj.findById(id);
			if (optional.isPresent()) // if statement is implementing
			{
				return "DATA is not DELETED !!";
			} else {
				return "DATA is DELETED !!";
			}
		} catch (Exception ex) // exception is catched
		{
			throw new StockException(ex.getMessage());
		}

	}

	public Stock finddatainfobyid(int id) throws StockException { // method is implementing
		try {
			return daoobj.findById(id).get();
		} catch (Exception ex) // exception is catched
		{
			throw new StockException(ex.getMessage());
		}
	}

}
