package com.cap.exception;

/*User defined Exception class */
public class StockException extends Exception {
	public StockException() {
		super();
	}

	public StockException(String msg) {
		super(msg);
	}

}
