package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("studentsdetails")
public class Student {
	private int sid;
	private String sname;
	private String ssection;
	
	@Autowired
	private Address add;
	
	
	
	
	public Address getAdd() {
		return add;
	}
	public void setAdd(Address add) {
		this.add = add;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSsection() {
		return ssection;
	}
	public void setSsection(String ssection) {
		this.ssection = ssection;
	}
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", ssection=" + ssection + ", add=" + add + "]";
	}
	
	

}
