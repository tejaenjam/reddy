package com.example.demo;

import org.springframework.stereotype.Component;

@Component("addr")
public class Address {
private int shno;
private String scolony;
private String sstate;


public int getShno() {
	return shno;
}
public void setShno(int shno) {
	this.shno = shno;
}
public String getScolony() {
	return scolony;
}
public void setScolony(String scolony) {
	this.scolony = scolony;
}
public String getSstate() {
	return sstate;
}
public void setSstate(String sstate) {
	this.sstate = sstate;
}


@Override
public String toString() {
	return "Address [shno=" + shno + ", scolony=" + scolony + ", sstate=" + sstate + "]";
}



}
