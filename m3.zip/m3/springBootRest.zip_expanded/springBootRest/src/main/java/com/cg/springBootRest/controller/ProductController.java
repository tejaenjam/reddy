package com.cg.springBootRest.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springBootRest.bean.Product;
import com.cg.springBootRest.exception.ProductException;
import com.cg.springBootRest.service.ProductService;

	@RestController
	public class ProductController {
	    @Autowired
	    ProductService productService;
	    
	    
	    @RequestMapping("/products")
	    public List<Product> getAllProducts() throws ProductException{
	        return productService.getAllProducts();
	    }

	    @RequestMapping("/repos")
	    public Product getAllProductss() throws ProductException{
	        return productService.getAllProductsByQty();
	    }
	    
	    @RequestMapping(value="/product",method=RequestMethod.POST)  
	    // @PutMapping can also be used but we don't have to write method=RequestMethod.POST
	    public List<Product> addProduct(@RequestBody Product pro) throws ProductException{
	        return productService.addProduct(pro);
	    }
	    
	    @RequestMapping("/products/{id}")
	    public Product getProductById(@PathVariable Long id) throws ProductException{
	        return productService.getProductById(id);
	    }
	    
	    @RequestMapping("/pro/{price}")
	    public Product getProductByPrice(@PathVariable int price) throws ProductException{
	        return productService.getProductByPrice(price);
	    }
	    
	    @DeleteMapping("/products/{id}")
	    public ResponseEntity<String> deleteBook(@PathVariable Long id) throws ProductException{
	        productService.deleteProduct(id);
	        return new ResponseEntity<String>("Book with id"+id+"deleted",HttpStatus.OK);
	    }
	    
	    @PutMapping("/products/{id}")
	    public List<Product> updateBook(@PathVariable Long id,@RequestBody Product pro) throws ProductException{
	        return productService.updateProduct(id,pro);
	    }
}