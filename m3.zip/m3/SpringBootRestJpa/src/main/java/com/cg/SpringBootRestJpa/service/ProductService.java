package com.cg.SpringBootRestJpa.service;

import java.util.List;

import com.cg.SpringBootRestJpa.bean.Product;
//import com.cg.SpringBootRestJpa.exception.ProductException;

public interface ProductService 
{	
		public List<Product> addProduct(Product pro);
		public Product getProductById (long id);
		public void deleteProduct(long id);
		public List<Product> getAllProducts() ;
		public List<Product> updateProduct (long id, Product pro);
		public List<Product> findByQuantity();
	

}
