package com.capgemini.capstore.util;

public enum Status {
	Active, Blocked
}