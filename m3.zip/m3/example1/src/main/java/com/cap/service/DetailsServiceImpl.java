package com.cap.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.IDetailsDao;
import com.cap.entities.Student;

/**
 * marking with @Service ,@Service is similar to @Component but used for service implementations
 *  Spring will create object of DetailsServiceImpl class and will keep in bean factory
 */
@Service//@Component
@Transactional
public class DetailsServiceImpl implements IDetailsService {


    /**
     * spring will inject with object of DetailsDaoImpl class because @Autowired is mentioned here
     */
    @Autowired
    private IDetailsDao dao;
	

    public IDetailsDao getDao(){
        return dao;
    }

    public void setDao(com.cap.dao.IDetailsDao dao){
        this.dao=dao;
    }

    @Override
    public Student findUserById(int id) {
    	Student user= dao.findUserById(id);
       return user;
    }

    @Override
    public Student createUser(Student student) {
       // transaction opened by spring
         student= dao.createUser(student);
        //transaction closed by spring
        return student;
    }


    @Override
    public Student createUser(String name) {
        return dao.createUser(name);
    }
}











