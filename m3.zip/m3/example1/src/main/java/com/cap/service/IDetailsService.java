package com.cap.service;

import com.cap.entities.Student;




public interface IDetailsService {

    Student findUserById(int id);

    Student createUser(Student student);

    Student createUser(String name);
}

