package com.cap.controller;

import com.cap.dao.UserNotFoundException;
import com.cap.entities.Student;
import com.cap.service.IDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class UserRestController {


}
