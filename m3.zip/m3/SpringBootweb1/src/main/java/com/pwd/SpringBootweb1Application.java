package com.pwd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootweb1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootweb1Application.class, args);
	}

}
