package com.cap.xyzbank.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.xyzbank.dao.IDaoBank;
import com.cap.xyzbank.dao.IdaoTransaction;
import com.cap.xyzbank.entity.BankEntity;
import com.cap.xyzbank.entity.TransactionEntity;
import com.cap.xyzbank.exception.DataNotFoundException;

@Service
public class BankService implements IBankService {
	@Autowired
	IDaoBank bankdaoObject;
	@Autowired
	IdaoTransaction transdaoObject;
	int a12;

	public long Creation(BankEntity bankbean) {
		long accnumber = 12344 + Long.parseLong(bankbean.getBnum2());
		bankbean.setBacc(accnumber);
		bankdaoObject.save(bankbean);
		System.out.println(bankbean);
		return accnumber;
	}

	public int showbalance(long accountnumber,String password) throws DataNotFoundException {
		Optional<BankEntity> optional = bankdaoObject.findById(accountnumber);
		if (optional.isPresent()) {
			BankEntity bankbean = optional.get();
			if((bankbean.getBpass()).equals(password)){
			int balance = bankbean.getBbal();
			return balance;}
			else {
				throw new DataNotFoundException("ENTER CORRECT PASSWORD");
			}
		} else {
			throw new DataNotFoundException("ENTER CORRECT ACCOUNT NUMBER");
		}

	}

	public int deposit(long accountnumber, int depositamount,String password) throws DataNotFoundException {
		if(depositamount>0) {
		Optional<BankEntity> optional = bankdaoObject.findById(accountnumber);
		if (optional.isPresent()) {
			BankEntity bankbean = optional.get();
			if((bankbean.getBpass()).equals(password)){
			System.out.println("depositservice "+bankbean.getBbal());
			int a = bankbean.getBbal() + depositamount;
			System.out.println("final"+a);
			Date date = new Date();
			TransactionEntity transbean = new TransactionEntity();
			transbean.setBaccInitial(bankbean.getBacc());
			transbean.setBaccFinal(bankbean.getBbal());
			bankbean.setBbal(a);
			bankdaoObject.save(bankbean);
			transbean.setTransBal(a);
			transbean.setTransMetd("deposit");
			transbean.setTransdate(date);
			transdaoObject.save(transbean);
			return a;
			}else {
				throw new DataNotFoundException("ENTER CORRECT PASSWORD");
			}
		} else {
			throw new DataNotFoundException("ENTER CORRECT ACCOUNT NUMBER");
		}}else {
			throw new DataNotFoundException("ENTER VALID AMOUNT");
		}
	}

	public int withdraw(long accountnumber, int withdrawamount,String password) throws DataNotFoundException {
		Optional<BankEntity> optional = bankdaoObject.findById(accountnumber);
		if (optional.isPresent()) {
			BankEntity bankbean = optional.get();
			if((bankbean.getBpass()).equals(password)){
			if (bankbean.getBbal() > withdrawamount) {
				a12 = bankbean.getBbal() - withdrawamount;
				Date date = new Date();
				TransactionEntity transbean = new TransactionEntity();
				transbean.setBaccInitial(bankbean.getBacc());
				transbean.setBaccFinal(bankbean.getBbal());
				bankbean.setBbal(a12);
				bankdaoObject.save(bankbean);
				transbean.setTransBal(a12);
				transbean.setTransMetd("withdraw");
				transbean.setTransdate(date);
				transdaoObject.save(transbean);
				return a12;

			} else {
				throw new DataNotFoundException("WITHDRAW AMOUNT SHOULD BE LESS THAN ACCOUNT BALANCE");
			}
			}else {
			throw new DataNotFoundException("ENTER CORRECT PASSWORD");	
			}
		} else {
			throw new DataNotFoundException("ENTER CORRECT ACCOUNT NUMBER");
		}
	}

	public int fundtransfer(long accountnumber1, long accountnumber2, int fundamount,String password) throws DataNotFoundException {
		Optional<BankEntity> optional = bankdaoObject.findById(accountnumber1);
		if (optional.isPresent()) {
			Optional<BankEntity> optional1 = bankdaoObject.findById(accountnumber2);
			if (optional1.isPresent()) {

				BankEntity bankbean1 = optional.get();
				if((bankbean1.getBpass()).equals(password)){
				if (bankbean1.getBbal() < fundamount) {
					throw new DataNotFoundException("FUND AMOUNT  SHOULD BE LESS THAN ACCOUNT BALANCE");
				} else {
					BankEntity bankbean2 = optional1.get();
					int a = bankbean1.getBbal() - fundamount;
					int a1 = bankbean2.getBbal() + fundamount;
					Date date = new Date();
					TransactionEntity transbean = new TransactionEntity();
					transbean.setBaccInitial(bankbean1.getBacc());
					transbean.setBaccFinal(bankbean1.getBbal());
					bankbean1.setBbal(a);
					bankdaoObject.save(bankbean1);
					transbean.setTransBal(a);
					transbean.setTransMetd("fundTransfer 1");
					transbean.setTransdate(date);
					transdaoObject.save(transbean);
					TransactionEntity transbean1 = new TransactionEntity();
					transbean1.setBaccInitial(bankbean2.getBacc());
					transbean1.setBaccFinal(bankbean2.getBbal());
					bankbean2.setBbal(a1);
					bankdaoObject.save(bankbean2);
					transbean1.setTransBal(a1);
					transbean1.setTransMetd("fundtransfer 2");
					transbean1.setTransdate(date);
					transdaoObject.save(transbean1);
 
					return a;
				}
			} else {
				throw new DataNotFoundException("ENTER CORRECT ACCOUNT NUMBER 2 ");
			}
				
			}else {
				throw new DataNotFoundException("ENTER CORRECT PASSWORD");
			}
		} else {
			throw new DataNotFoundException("ENTER CORRECT ACCOUNT NUMBER 1 ");

		}

	}

	public List<TransactionEntity> printtransaction(long accountnumber,String password) throws DataNotFoundException {
		
		return transdaoObject.findBybaccInitial(accountnumber);
	}

}
