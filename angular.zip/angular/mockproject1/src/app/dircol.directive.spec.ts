import { DircolDirective } from './dircol.directive';

describe('DircolDirective', () => {
  it('should create an instance', () => {
    const directive = new DircolDirective();
    expect(directive).toBeTruthy();
  });
});
