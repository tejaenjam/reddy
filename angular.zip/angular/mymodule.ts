export class emp{
    constructor(private p1:string,private p2:string){
    }
    sd1(){
        return this.p1+" "+this.p2;
    }
}
export class stu{
    constructor(private p3:number,private p4:string){}
    sd1(){
        return this.p3+" "+this.p4;
    }
}
