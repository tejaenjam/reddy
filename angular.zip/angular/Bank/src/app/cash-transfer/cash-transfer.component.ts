import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cash-transfer',
  templateUrl: './cash-transfer.component.html',
  styleUrls: ['./cash-transfer.component.css']
})
export class CashTransferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
