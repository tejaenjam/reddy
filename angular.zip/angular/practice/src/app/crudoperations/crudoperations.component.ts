import { Component, OnInit } from '@angular/core';
import { SlayerService, employeebean } from '../slayer.service';

@Component({
  selector: 'app-crudoperations',
  templateUrl: './crudoperations.component.html',
  styleUrls: ['./crudoperations.component.css']
})
export class CrudoperationsComponent implements OnInit {
service:SlayerService;
emp:employeebean[];

  constructor(service:SlayerService) {this.service=service; }

  delete(id:number)
  {
    this.service.delete(id);
    this.emp=this.service.getinfo();
  }
  // isUpdate:boolean=true;
  // updateData()
  // {
  //   this.isUpdate=!this.isUpdate;
  // }

  coloum:any;
  order:boolean=false
sort(coloum:any)
{
  if(this.coloum==coloum)
  {
    this.order=!this.order;
  }else
  {
    this.coloum=coloum;
    this.order=true;
  }
}


  ngOnInit() {
    this.service.fetchinfo();
    this.emp=this.service.getinfo();

  }

}
