import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Crudoperations2Component } from './crudoperations2.component';

describe('Crudoperations2Component', () => {
  let component: Crudoperations2Component;
  let fixture: ComponentFixture<Crudoperations2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Crudoperations2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Crudoperations2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
