import { Component, OnInit } from '@angular/core';
import { SlayerService, employeebean } from '../slayer.service';

@Component({
  selector: 'app-crudoperations2',
  templateUrl: './crudoperations2.component.html',
  styleUrls: ['./crudoperations2.component.css']
})
export class Crudoperations2Component implements OnInit {
service:SlayerService;
emp:employeebean[];
// as:boolean=false;
  constructor(service:SlayerService) { this.service=service;}
  update(data:any)
  {
    
    this.service.update(data);
    this.emp=this.service.getinfo();
    // this.as=true;
  }
  // isUpdate:boolean=true;
  // updateData()
  // {
  //   this.isUpdate=!this.isUpdate;
  // }

  // for(let a in data)
  // for(let b of data[a])
  // b.id
  ngOnInit() {
  }

}
