import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchopComponent } from './searchop.component';

describe('SearchopComponent', () => {
  let component: SearchopComponent;
  let fixture: ComponentFixture<SearchopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
