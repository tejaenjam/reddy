import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CrudoperationsComponent } from './crudoperations/crudoperations.component';
import { Crudoperations1Component } from './crudoperations1/crudoperations1.component';
import { Crudoperations2Component } from './crudoperations2/crudoperations2.component';
import { SearchopComponent } from './searchop/searchop.component';


const routes: Routes = [ 
{path:"path1",component:CrudoperationsComponent},
{path:"path2",component:Crudoperations1Component},
{path:"path3",component:Crudoperations2Component},
{path:"path4",component:SearchopComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
