import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mydate2',
  templateUrl: './date1.component.html',
  styleUrls: ['./date1.component.css']
})
export class Date1Component implements OnInit {


  mydate:string; 
  constructor() {
   // let mydate1 = new Date();
   // this.mydate=mydate1.toDateString();
   let a=()=>{let mydate1 = new Date();
    this.mydate=mydate1.toLocaleTimeString()+"  "+mydate1.toDateString()}
    setInterval(a,1000)
   }
  ngOnInit() {
  }

}
