import { Directive ,ElementRef} from '@angular/core';

@Directive({
  selector: '[Dirpip]'
})
export class DirpipDirective {

  constructor(private e:ElementRef) { 
    e.nativeElement.style.color="blue"
    e.nativeElement.style.backgroundColor="yellow"
  }

}
