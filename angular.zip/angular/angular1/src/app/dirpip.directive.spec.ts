import { DirpipDirective } from './dirpip.directive';

describe('DirpipDirective', () => {
  it('should create an instance', () => {
    const directive = new DirpipDirective();
    expect(directive).toBeTruthy();
  });
});
