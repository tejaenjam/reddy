import { Component, OnInit, Input } from '@angular/core';
import { empbean } from './employeebean';

@Component({
  selector: 'employeechild',
  templateUrl: './employeedatails.component.html',
  styleUrls: ['./employeedatails.component.css']
})
export class EmployeedatailsComponent implements OnInit {

@Input ("empobj") employeeobject:any[]
  constructor() {
   }

  ngOnInit() {
  }

}
