export class empbean{
    eid:number;
    ename:string;
    edesignation:string;
    eaddress:string;
    econtact:string[];
}