import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PipeexamleComponent } from './pipeexamle.component';

describe('PipeexamleComponent', () => {
  let component: PipeexamleComponent;
  let fixture: ComponentFixture<PipeexamleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PipeexamleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PipeexamleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
