import { Component, OnInit, Input } from '@angular/core';
import { empbean } from '../employeedatails/employeebean';

@Component({
  selector: 'twowaydatabinding',
  templateUrl: './twowaydatabinding.component.html',
  styleUrls: ['./twowaydatabinding.component.css']
})
export class TwowaydatabindingComponent implements OnInit {
  
  emp1:empbean;
  constructor() {
    this.emp1=new empbean();
    this.emp1.eid=123;
    this.emp1.ename='ARAVIND REDDY';
    this.emp1.edesignation='ANALYST';
    this.emp1.eaddress="hyderabad";
    this.emp1.econtact=['7093117585','8790992925'];
    
   }
  ngOnInit() {
  }

}
