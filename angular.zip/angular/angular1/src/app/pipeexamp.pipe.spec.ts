import { PipeexampPipe } from './pipeexamp.pipe';

describe('PipeexampPipe', () => {
  it('create an instance', () => {
    const pipe = new PipeexampPipe();
    expect(pipe).toBeTruthy();
  });
});
