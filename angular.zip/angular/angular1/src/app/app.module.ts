import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Date1Component } from './date1/date1.component';
import { EmployeedatailsComponent } from './employeedatails/employeedatails.component';
import { EmponclickComponent } from './emponclick/emponclick.component';
import { TwowaydatabindingComponent } from './twowaydatabinding/twowaydatabinding.component';
import { PipeexamleComponent } from './pipeexamle/pipeexamle.component';
import { PipeexampPipe } from './pipeexamp.pipe';
import { DirpipDirective } from './dirpip.directive';

@NgModule({
  declarations: [
    AppComponent,
    Date1Component,
    EmployeedatailsComponent,
    EmponclickComponent,
    TwowaydatabindingComponent,
    PipeexamleComponent,
    PipeexampPipe,
    DirpipDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
