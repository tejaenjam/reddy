import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmponclickComponent } from './emponclick.component';

describe('EmponclickComponent', () => {
  let component: EmponclickComponent;
  let fixture: ComponentFixture<EmponclickComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmponclickComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmponclickComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
