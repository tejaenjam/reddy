import { Component, OnInit, Input } from '@angular/core';
import { empbean } from '../employeedatails/employeebean';

@Component({
  selector: 'emponclick',
  templateUrl: './emponclick.component.html',
  styleUrls: ['./emponclick.component.css']
})
export class EmponclickComponent implements OnInit {

  @Input ("empobj") employeeobject:any[]
  constructor() { }

  ngOnInit() {
  }
  a:boolean=true;
  check()
  {
this.a=!this.a;
  }
}
