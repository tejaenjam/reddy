import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pipeexamle',
  templateUrl: './pipeexamle.component.html',
  styleUrls: ['./pipeexamle.component.css']
})
export class PipeexamleComponent implements OnInit {
empl:any[];
  constructor() {
  this.empl=[{name:"aravind",gender:"male",id:879099,salary:123456,dob:"22-06-1997"},{name:"keshireddy",gender:"male",id:709311,salary:564123,dob:"2-06-1997"}
,{name:"sreeja",gender:"female",id:800823,salary:73456,dob:"8-6-1997"}]
   }

  ngOnInit() {
  }

}
