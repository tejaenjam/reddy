import { Component } from '@angular/core';
import { empbean } from './employeedatails/employeebean';

@Component({
  selector: 'class1',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
 a1 = 'Today Date';
 emp1:empbean;
 emp2:empbean;
 emp:any[]
 //<p><employeechild [empobj] = "emp"> </employeechild></p>
 constructor()
 {
  this.emp1=new empbean();
  this.emp1.eid=123;
  this.emp1.ename='ARAVIND REDDY';
  this.emp1.edesignation='ANALYST';
  this.emp1.eaddress="hyderabad";
  this.emp1.econtact=['7093117585','8790992925'];

  this.emp2=new empbean();
  this.emp2.eid=94834;
  this.emp2.ename='KESHIREDDY';
  this.emp2.edesignation='A4';
  this.emp2.eaddress="Chennai";
  this.emp2.econtact=['8008966655','8456985236'];
  
  this.emp=[this.emp1,this.emp2]
}
}
