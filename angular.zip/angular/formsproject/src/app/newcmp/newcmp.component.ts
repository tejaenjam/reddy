import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-newcmp',
  templateUrl: './newcmp.component.html',
  styleUrls: ['./newcmp.component.css']
})
export class NewcmpComponent implements OnInit {

  constructor() { }
  employeForm:FormGroup;
  ngOnInit() {
    this.employeForm=new FormGroup({
      fullname: new FormControl(),
      email:new FormControl
    });
  }

  onsubmit():void{
    console.log(this.employeForm.value);
    console.log(this.employeForm.controls.fullname.value)
    alert(this.employeForm.get("fullname").value);
  }
}
