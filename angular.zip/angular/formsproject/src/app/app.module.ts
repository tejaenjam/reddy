import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewcmpComponent } from './newcmp/newcmp.component';
import {FormsModule} from '@angular/forms';
import{ TemplatedrivenComponent} from'./


@NgModule({
  declarations: [
    AppComponent,
    NewcmpComponent,TemplatedrivenComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
