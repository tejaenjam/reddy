"use strict";
exports.__esModule = true;
var mymodule_1 = require("../angular/mymodule");
var st = new mymodule_1.stu(1, "aravind");
var re1 = st.sd1();
console.log('stu details' + re1);
var emp2 = new mymodule_1.emp("keshireddy", "reddy");
var re2 = emp2.sd1();
console.log('emp details' + re2);
