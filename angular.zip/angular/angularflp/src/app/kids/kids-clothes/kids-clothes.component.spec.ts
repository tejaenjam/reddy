import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KidsClothesComponent } from './kids-clothes.component';

describe('KidsClothesComponent', () => {
  let component: KidsClothesComponent;
  let fixture: ComponentFixture<KidsClothesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KidsClothesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KidsClothesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
