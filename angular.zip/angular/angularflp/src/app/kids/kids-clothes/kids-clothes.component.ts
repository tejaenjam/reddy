import { Component, OnInit } from '@angular/core';
import { Product } from 'src/model/Product';
import { Router } from '@angular/router';
import { ProductServiceService } from 'src/app/product-service.service';

@Component({
  selector: 'kids-clothes',
  templateUrl: './kids-clothes.component.html',
  styleUrls: ['./kids-clothes.component.css']
})
export class KidsClothesComponent implements OnInit {

  products:Product[]=[];
  constructor(private router:Router,private service:ProductServiceService) { }

  ngOnInit() {

    this.service.searchByCategory("Kids","Clothes").subscribe(data=>{console.log(data);this.products=data;});
  }
}
