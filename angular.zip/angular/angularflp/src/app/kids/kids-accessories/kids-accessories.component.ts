import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductServiceService } from 'src/app/product-service.service';
import { Product } from 'src/model/Product';

@Component({
  selector: 'kids-accessories',
  templateUrl: './kids-accessories.component.html',
  styleUrls: ['./kids-accessories.component.css']
})
export class KidsAccessoriesComponent implements OnInit {
products:Product[]=[];
  constructor(private router:Router,private service:ProductServiceService) { }

  ngOnInit() {

    this.service.searchByCategory("Kids","Accessories").subscribe(data=>{console.log(data);this.products=data;});
  }

}
