import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { KidsComponent } from './kids/kids.component';
import { MenComponent } from './men/men.component';
import { WomenComponent } from './women/women.component';
import { WomenAccessoriesComponent } from './women/women-accessories/women-accessories.component';
import { MenAccessoriesComponent } from './men/men-accessories/men-accessories.component';
import { KidsAccessoriesComponent } from './kids/kids-accessories/kids-accessories.component';
import { KidsClothesComponent } from './kids/kids-clothes/kids-clothes.component';
import { WomenClothesComponent } from './women/women-clothes/women-clothes.component';
import { MenFootwearComponent } from './men/men-footwear/men-footwear.component';
import { MenClothesComponent } from './men/men-clothes/men-clothes.component';
import { KidsFootwearComponent } from './kids/kids-footwear/kids-footwear.component';
import { WomenFootwearComponent } from './women/women-footwear/women-footwear.component';
import { MenWatchesComponent } from './men/men-watches/men-watches.component';
import { WomenWatchesComponent } from './women/women-watches/women-watches.component';
import { SearchComponent } from './search/search.component';
import { ViewDescriptionComponent } from './view-description/view-description.component';


const routes: Routes = [
  {
    path:"" , redirectTo:"app-search", pathMatch:"full"
  },
  {
    path:'app-search',
    component:SearchComponent
  },
  {
    path:'app-kids',
    component:KidsComponent
  },
  {
    path:'app-men',
    component:MenComponent
  },
  {
    path:'app-women',
    component:WomenComponent
  },
  {
    path:'app-women/women-accessories',
    component:WomenAccessoriesComponent
  },
  {
    path:'app-men/men-accessories',
    component:MenAccessoriesComponent
  },
  {
    path:'app-kids/kids-accessories',
    component:KidsAccessoriesComponent
  },
  {
    path:'app-kids/kids-clothes',
    component:KidsClothesComponent
  },
  {
    path:'app-women/women-clothes',
    component:WomenClothesComponent
  },
  {
    path:'app-men/men-clothes',
    component:MenClothesComponent
  },
  {
    path:'app-men/men-footwear',
    component:MenFootwearComponent
  },
  {
    path:'app-women/women-footwear',
    component:WomenFootwearComponent

  },
  {
    path:'app-kids/kids-footwear',
    component:KidsFootwearComponent
  },{
    path:'app-men/men-watches',
    component:MenWatchesComponent
  },
  {
    path:'app-women/women-watches',
    component:WomenWatchesComponent
  },
  {
    path:'view-description',
    component:ViewDescriptionComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
