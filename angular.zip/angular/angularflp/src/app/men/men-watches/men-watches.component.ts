import { Component, OnInit } from '@angular/core';
import { Product } from 'src/model/Product';
import { Router } from '@angular/router';
import { ProductServiceService } from 'src/app/product-service.service';

@Component({
  selector: 'men-watches',
  templateUrl: './men-watches.component.html',
  styleUrls: ['./men-watches.component.css']
})
export class MenWatchesComponent implements OnInit {

  products:Product[]=[];
  constructor(private router:Router,private service:ProductServiceService) { }

  ngOnInit() {

    this.service.searchByCategory("Men","Watches").subscribe(data=>{console.log(data);this.products=data;});
  }

}
