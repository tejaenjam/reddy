import { Component, OnInit } from '@angular/core';
import { Product } from 'src/model/Product';
import { Router } from '@angular/router';
import { ProductServiceService } from 'src/app/product-service.service';

@Component({
  selector: 'men-accessories',
  templateUrl: './men-accessories.component.html',
  styleUrls: ['./men-accessories.component.css']
})
export class MenAccessoriesComponent implements OnInit {
  products:Product[]=[];
  description:boolean=false;
  product:Product;
  constructor(private router:Router,private service:ProductServiceService) { }

  ngOnInit() {

    this.service.searchByCategory("Men","Accessories").subscribe(data=>{console.log(data);this.products=data;});
  }
  
  showDescription(data:any){
    this.service.setData(data);
    this.router.navigate(['view-description']);
  // this.description = true;
  // this.product=data;
}
}
