import { Component, OnInit } from '@angular/core';
import { Product } from 'src/model/Product';
import { Router } from '@angular/router';
import { ProductServiceService } from 'src/app/product-service.service';

@Component({
  selector: 'men-footwear',
  templateUrl: './men-footwear.component.html',
  styleUrls: ['./men-footwear.component.css']
})
export class MenFootwearComponent implements OnInit {
  products:Product[]=[];
  constructor(private router:Router,private service:ProductServiceService) { }

  ngOnInit() {

    this.service.searchByCategory("Men","Footwear").subscribe(data=>{console.log(data);this.products=data;});
  }

}
