import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from 'src/model/Product';
import { ProductServiceService } from 'src/app/product-service.service';

@Component({
  selector: 'men-clothes',
  templateUrl: './men-clothes.component.html',
  styleUrls: ['./men-clothes.component.css']
})
export class MenClothesComponent implements OnInit {

  products:Product[]=[];
  constructor(private router:Router,private service:ProductServiceService) { }

  ngOnInit() {

    this.service.searchByCategory("Men","Clothes").subscribe(data=>{console.log(data);this.products=data;});
  }

}
