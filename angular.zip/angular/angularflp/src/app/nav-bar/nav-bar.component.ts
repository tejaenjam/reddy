import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductServiceService } from '../product-service.service';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  constructor(private router:Router,private service:ProductServiceService) { }
onsearch(name:string){
this.router.navigate(['/app-search', {product:'havhvh' }])
}
  ngOnInit() {
  }

}
