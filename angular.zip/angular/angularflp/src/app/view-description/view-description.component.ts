import { Component, OnInit } from '@angular/core';
import { ProductServiceService } from '../product-service.service';
import { Product } from 'src/model/Product';

@Component({
  selector: 'view-description',
  templateUrl: './view-description.component.html',
  styleUrls: ['./view-description.component.css']
})
export class ViewDescriptionComponent implements OnInit {
 product:Product;
  constructor(private service:ProductServiceService) { }

  ngOnInit() {
this.product=this.service.getData();
console.log(this.product);

  }

}
