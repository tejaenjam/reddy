import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute,ParamMap } from '@angular/router';
import { ProductServiceService } from '../product-service.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
products:any[]=[];

  constructor( private router:Router,private service:ProductServiceService) {
    
   }
search(item:any){
  if(item!=null){
    this.products=[];
    this.service.searchByName(item.items).subscribe(data=>{this.products=data;console.log(data);});
  }
else{
  alert("Search field is empty")
}

//this.products.push(data.search);
  //alert(data.search);
}
  ngOnInit() {
// //let id = this.route.snapshot.paramMap.get('name');
// this.route.params.subscribe(params => {
//   console.log(params);
// });
// // alert(id);
// // console.log(id);



  }

}
