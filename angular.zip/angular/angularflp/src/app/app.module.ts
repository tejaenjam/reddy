import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenComponent } from './men/men.component';
import { WomenComponent } from './women/women.component';
import { KidsComponent } from './kids/kids.component';
import { SearchComponent } from './search/search.component';
import { MenAccessoriesComponent } from './men/men-accessories/men-accessories.component';
import { WomenAccessoriesComponent } from './women/women-accessories/women-accessories.component';
import { KidsAccessoriesComponent } from './kids/kids-accessories/kids-accessories.component';
import { MenFootwearComponent } from './men/men-footwear/men-footwear.component';
import { KidsFootwearComponent } from './kids/kids-footwear/kids-footwear.component';
import { WomenFootwearComponent } from './women/women-footwear/women-footwear.component';
import { MenClothesComponent } from './men/men-clothes/men-clothes.component';
import { WomenClothesComponent } from './women/women-clothes/women-clothes.component';
import { KidsClothesComponent } from './kids/kids-clothes/kids-clothes.component';
import { MenWatchesComponent } from './men/men-watches/men-watches.component';
import { WomenWatchesComponent } from './women/women-watches/women-watches.component';
import { ProductServiceService } from './product-service.service';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { ViewDescriptionComponent } from './view-description/view-description.component';



@NgModule({
  declarations: [
    AppComponent,
    MenComponent,
    WomenComponent,
    KidsComponent,
    SearchComponent,
    MenAccessoriesComponent,
    WomenAccessoriesComponent,
    KidsAccessoriesComponent,
    MenFootwearComponent,
    KidsFootwearComponent,
    WomenFootwearComponent,
    MenClothesComponent,
    WomenClothesComponent,
    KidsClothesComponent,
    MenWatchesComponent,
    WomenWatchesComponent,
    NavBarComponent,
    HomeComponent,
    ViewDescriptionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,ProductServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
