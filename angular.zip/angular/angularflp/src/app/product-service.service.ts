import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from 'src/model/Product';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {
  // products:Product []=[] ;
  product:Product;
  constructor(private http:HttpClient) {
    this.http=http;
   }
setData(data:Product){
this.product=data;
}
getData():Product{
  return this.product;
  }
  getProducts():Observable<Product[]>{
    let url='http://localhost:1235/products';
    return this.http.get<Product[]>(url);
  }

 searchByCategory(gender:string,category:string):Observable<Product[]>{

  let url="http://localhost:1235/searchByCategory"
  return this.http.get<Product[]>(url+"/"+gender+"/"+category);

 }

  searchByName(productName:string):Observable<Product[]>{
    // let jsonObject={"productName":productName}
    let url="http://localhost:1235/searchByName/"+productName;
    return this.http.get<Product[]>(url);

  }
}
