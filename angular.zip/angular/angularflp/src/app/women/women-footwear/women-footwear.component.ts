import { Component, OnInit } from '@angular/core';
import { Product } from 'src/model/Product';
import { Router } from '@angular/router';
import { ProductServiceService } from 'src/app/product-service.service';

@Component({
  selector: 'women-footwear',
  templateUrl: './women-footwear.component.html',
  styleUrls: ['./women-footwear.component.css']
})
export class WomenFootwearComponent implements OnInit {
  products:Product[]=[];
  constructor(private router:Router,private service:ProductServiceService) { }

  ngOnInit() {

    this.service.searchByCategory("Women","Footwear").subscribe(data=>{console.log(data);this.products=data;});
  }

}
