import { Component, OnInit } from '@angular/core';
import { Product } from 'src/model/Product';
import { Router } from '@angular/router';
import { ProductServiceService } from 'src/app/product-service.service';

@Component({
  selector: 'women-accessories',
  templateUrl: './women-accessories.component.html',
  styleUrls: ['./women-accessories.component.css']
})
export class WomenAccessoriesComponent implements OnInit {

  products:Product[]=[];
  constructor(private router:Router,private service:ProductServiceService) { }

  ngOnInit() {

    this.service.searchByCategory("Women","Accessories").subscribe(data=>{console.log(data);this.products=data;});
  }
}
