import { Component, OnInit } from '@angular/core';
import { Product } from 'src/model/Product';
import { Router } from '@angular/router';
import { ProductServiceService } from 'src/app/product-service.service';

@Component({
  selector: 'women-clothes',
  templateUrl: './women-clothes.component.html',
  styleUrls: ['./women-clothes.component.css']
})
export class WomenClothesComponent implements OnInit {

  products:Product[]=[];
  constructor(private router:Router,private service:ProductServiceService) { }

  ngOnInit() {

    this.service.searchByCategory("Women","Clothes").subscribe(data=>{console.log(data);this.products=data;});
  }

}
