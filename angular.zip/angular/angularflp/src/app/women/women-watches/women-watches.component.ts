import { Component, OnInit } from '@angular/core';
import { Product } from 'src/model/Product';
import { Router } from '@angular/router';
import { ProductServiceService } from 'src/app/product-service.service';

@Component({
  selector: 'women-watches',
  templateUrl: './women-watches.component.html',
  styleUrls: ['./women-watches.component.css']
})
export class WomenWatchesComponent implements OnInit {

  products:Product[]=[];
  constructor(private router:Router,private service:ProductServiceService) { }

  ngOnInit() {

    this.service.searchByCategory("Women","Watches").subscribe(data=>{console.log(data);this.products=data;});
  }

}
