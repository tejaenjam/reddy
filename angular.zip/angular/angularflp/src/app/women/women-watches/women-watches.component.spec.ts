import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WomenWatchesComponent } from './women-watches.component';

describe('WomenWatchesComponent', () => {
  let component: WomenWatchesComponent;
  let fixture: ComponentFixture<WomenWatchesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WomenWatchesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WomenWatchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
