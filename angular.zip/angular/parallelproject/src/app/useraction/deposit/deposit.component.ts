import { Component, OnInit } from '@angular/core';
import { ServicelayerService } from 'src/app/servicelayer.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  servicelayer:ServicelayerService;
  constructor(  servicelayer:ServicelayerService) { 
    this.servicelayer=servicelayer;
  }

  deposit(data:any)
  {
    this.servicelayer.deposit(data.accountnumber,data.password,data.depositbalance)
  }
  ngOnInit() {
  }

}
