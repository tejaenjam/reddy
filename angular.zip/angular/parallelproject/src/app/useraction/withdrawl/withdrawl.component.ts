import { Component, OnInit } from '@angular/core';
import { ServicelayerService } from 'src/app/servicelayer.service';

@Component({
  selector: 'app-withdrawl',
  templateUrl: './withdrawl.component.html',
  styleUrls: ['./withdrawl.component.css']
})
export class WithdrawlComponent implements OnInit {
  servicelayer:ServicelayerService;
  constructor( servicelayer:ServicelayerService) {this.servicelayer=servicelayer }
  withdraw(data:any){
    console.log("asfasf")
    this.servicelayer.withdraw(data.accountnumber,data.password,data.withdrawbalance)
  }
  ngOnInit() {
  }

}
