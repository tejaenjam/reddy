import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ServicelayerService {
  
  
  router:Router;
  bankdetails:BankBean[]=[];
  ht:HttpClient;
  constructor( ht:HttpClient,router:Router) { this.ht=ht;this.router=router
  }

  ab:boolean=false;               
  FetchingData(){                  
    this.ht.get("./assets/data.json").subscribe 
    (info=>{                                    
      if(!this.ab)                   
      {
       this.Method1(info);         
        this.ab=true;              
      }
    });

  }

  Method1(info :any)                   
  {
    for(let data of info)  
    {                
      let e=new BankBean(data.newcustomername,data.newphonenumber,data.newdateofbirth,data.newpassword,data.newlocation,data.newaccounttype,data.newbalance,data.customeraccountnumber,data.statement) 
      this.bankdetails.push(e);           
    }
  }

   createaccount(o:any) {
     this.bankdetails.push(o);
     alert("ACCOUNT NUMBER :"+o.customeraccountnumber) 
     this.router.navigate(['useraction']);
   }

   showbalance(accountnumber: any, password: any): any {
    for(let i=0;i<this.bankdetails.length;i++)
   {
     if(this.bankdetails[i].customeraccountnumber==accountnumber)
       {
       if(this.bankdetails[i].password==password)
        {
        alert("Balance is :"+this.bankdetails[i].balance);
        this.router.navigate(['useraction']);
        }else{
       alert("Enter correct password")
       }
     }else{
       alert("Enter valid account number")
     }
   }
  }

   deposit(accountnumber: any, password: any, depositbalance: any): any
   {
   for(let i=0;i<this.bankdetails.length;i++)
   {
     if(this.bankdetails[i].customeraccountnumber==accountnumber)
       {
       if(this.bankdetails[i].password==password)
        {
         this.bankdetails[i].balance=this.bankdetails[i].balance+depositbalance;
         alert("UPDATED BALANCE AFTER DEPOSIT IS :"+  this.bankdetails[i].balance)
         this.bankdetails[i].statement +="\n"+" :  ACCOUNT NUMBER  :"+this.bankdetails[i].customeraccountnumber+" :  FINAL BALANCE  :"+this.bankdetails[i].balance+" :  METHOD TYPE :"+"  DEPOSIT";
         this.router.navigate(['useraction']);
        }else{
       alert("Enter correct password")
       }
     }else{
       alert("Enter valid account number")
     }
   }
 }

 withdraw(accountnumber: any, password: any, withdrawbalance: any): any {
  
  for(let i=0;i<this.bankdetails.length;i++)
  {
    
    if(this.bankdetails[i].customeraccountnumber==accountnumber)
      {
      if(this.bankdetails[i].password==password)
       {
        if( this.bankdetails[i].balance > withdrawbalance)
        {this.bankdetails[i].balance=this.bankdetails[i].balance-withdrawbalance;
          this.bankdetails[i].statement +="\n"+": ACCOUNT NUMBER :"+this.bankdetails[i].customeraccountnumber+":   FINAL BALANCE  :"+this.bankdetails[i].balance+" :  METHOD TYPE :"+"withdraw";
          alert("UPDATED BALANCE AFTER WITHDRAW Is :"+  this.bankdetails[i].balance);
          this.router.navigate(['useraction']);
        }else{
          alert("enter balance less than account balance")
          this.router.navigate(['useraction']);
        }
       }else{
        
      alert("Enter correct password")
      
      }
    }else{
     
      alert("Enter valid account number")

    }
  }
}


fundtransfer(accountnumber1: number, password1: string, accountnumber2: number, fundtransferamount: number) 
{

  let flag=0;
  for(let i=0;i<this.bankdetails.length;i++)
  {
    if(this.bankdetails[i].customeraccountnumber==accountnumber1 && this.bankdetails[i].password==password1 )
    {
      if(this.bankdetails[i].balance>fundtransferamount){
      this.bankdetails[i].balance=this.bankdetails[i].balance-fundtransferamount;
      this.bankdetails[i].statement +="\n"+": ACCOUNT NUMBER :"+this.bankdetails[i].customeraccountnumber+" :  FINAL BALANCE  :"+this.bankdetails[i].balance+": METHOD TYPE :"+"FUNDTRANSFER";
      alert("Balance AFTER FUND TRANSFER 1:"+ this.bankdetails[i].balance)
      flag=1;
      }
      else{
        alert("enter balance less than account balance")
      }
    }
  }
  if(flag==0){
    alert("Enter Your account Number or password correctly ");
    return;
  }



  let flag1=0;
  for(let i=0;i<this.bankdetails.length;i++)
  {
    if(this.bankdetails[i].customeraccountnumber==accountnumber2)
    { 
      if(this.bankdetails[i].balance>fundtransferamount){
      this.bankdetails[i].balance=this.bankdetails[i].balance+fundtransferamount;
      this.bankdetails[i].statement += "\n"+"ACCOUNT NUMBER   :"+this.bankdetails[i].customeraccountnumber+" :  FINAL BALANCE  :"+this.bankdetails[i].balance+" :  METHOD TYPE :"+"FUNDTRANSFER";
      alert("Balance AFTER FUND TRANSFER 2:"+ this.bankdetails[i].balance)
      this.router.navigate(['useraction']);
      flag1=1;
      }else{
        alert("enter balance less than account balance")
      }
    }
  }

  if(flag1==0){
    alert("Enter Your account Number correctly ");
  }
}

transaction(accountnumber: any, password: any): any {
  for(let i=0;i<this.bankdetails.length;i++)
   {
     if(this.bankdetails[i].customeraccountnumber==accountnumber)
       {
       if(this.bankdetails[i].password==password)
        {
        alert("TRANSACTION DETAILS ARE :  \n"+this.bankdetails[i].statement);
        this.router.navigate(['useraction']);
        }else{
       alert("Enter correct password")
       }
     }else{
       alert("Enter valid account number")
     }
   }
}



}

export class BankBean{
  customeraccountnumber:number;                       
  customername:string; 
  phonenumber:number;                                  
  dateofbirth:string;
  password:string;
  location:string;
  accounttype:string;
  balance:number;
  statement:string;
   constructor( customername:string,phonenumber:number,dateofbirth:string,password:string,location:string,accounttype:string,balance:number, customeraccountnumber:number,statement:string)  //default constructor
     {
        this.customername=customername;
        this.phonenumber=phonenumber;
        this.dateofbirth=dateofbirth;
        this.password=password;
        this.location=location;
        this.accounttype=accounttype;
        this.balance=balance;
        this.customeraccountnumber=customeraccountnumber;
        this.statement=statement;
      }
}
