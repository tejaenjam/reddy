import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceLayerService {
  empdetails:EmployeeBean[]=[];  //EmployeeBean class arrray creation
  ht:HttpClient;                  //httpClient class object creation
  constructor( ht:HttpClient) {   //default constructor of ServiceLayerService class
    this.ht=ht;                   //globallising
   }

   ab:boolean=false;               //boolean false is updating into ab variable
   FetchingData(){                  //fetchingData  Method is implementing
     this.ht.get("./assets/EmployeeDetails.json").subscribe   //get method present in httpclient is using to fetch  the values in json file 
     (info=>{                                    
       if(!this.ab)                   //loop executes only once
       {
        this.Method1(info);         //method1 is calling 
         this.ab=true;               //updation of ab value
       }
     });
   }
   
   Method1(info :any)                   //method1 is implementing
   {
     for(let o of info)                   //for loop to fetch the data from jsaon to employeebean class 
     {
       let e=new EmployeeBean(o.eid,o.ename,o.eEmail,o.ephone)  //fetching values one by one
       this.empdetails.push(e);           //pushing  the values into empdetails array
     }
   }
   
   
   GettingInformation():EmployeeBean[]{      //gettinginformation method is implementing and return type  is an array 
     return this.empdetails;   //returning the values in the form of array
   }
   
    
   DeleteData(id1:number)                     //deletedata method is implementing
   {
     let  num:number=0;                        //intializing num=0
    for(let i=0;i< this.empdetails.length;i++)  //for loop to get data from employeebean class
    {
      let e=this.empdetails[i];
      if(id1==e.eid)                              //checking the data i.e; input data and real data is same or not 
      {
        num=i;                                   //updating num value with the index
        break;
      }
    }
    this.empdetails.splice(num,1);                //splice method is implementing for deletion
   }
   
   AddDetails(o:any)                          //adddetaisl method is implemneting
{
  this.empdetails.push(o);                 //pushing data into empdetails
}

}

export class EmployeeBean{                       //employeebean class 
  //intializing values
  eid:number;                                   
  ename:string;
  eEmail:string;
  ephone:string;
   constructor( eid:number,ename:string,eEmail:string,ephone:string)  //default constructor
     {
       //globallizing values
        this.eid=eid;
        this.ename=ename;
        this.eEmail=eEmail;
        this.ephone=ephone;
      }
}