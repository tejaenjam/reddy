import { Component, OnInit } from '@angular/core';
import { ServiceLayerService, EmployeeBean } from '../service-layer.service';

@Component({
  selector: 'app-list-all-employees',
  templateUrl: './list-all-employees.component.html',
  styleUrls: ['./list-all-employees.component.css']
})
export class ListAllEmployeesComponent implements OnInit {

servicelayer:ServiceLayerService;       //servicelayer object
empbean:EmployeeBean[];                    //employeebean class array

  constructor(servicelayer:ServiceLayerService) {this.servicelayer=servicelayer; }  //default constructor

  DeleteData(id:number)         //deletedata method implementing
  {
    this.servicelayer.DeleteData(id);     //deletedata method is calling which is present in service layer
    this.empbean=this.servicelayer.GettingInformation();   //GettingInformation method is calling which is present in service layer
  }

  ngOnInit() {
    this.servicelayer.FetchingData();            //FetchingData method is calling which is present in service layer
    this.empbean=this.servicelayer.GettingInformation();     //GettingInformation method is calling which is present in service layer
  }

}
