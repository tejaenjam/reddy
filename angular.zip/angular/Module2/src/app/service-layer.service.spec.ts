import { TestBed } from '@angular/core/testing';

import { ServiceLayerService } from './service-layer.service';

describe('ServiceLayerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ServiceLayerService = TestBed.get(ServiceLayerService);
    expect(service).toBeTruthy();
  });
});
