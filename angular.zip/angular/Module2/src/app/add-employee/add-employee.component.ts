import { Component, OnInit } from '@angular/core';
import { ServiceLayerService, EmployeeBean } from '../service-layer.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  servicelayer:ServiceLayerService;   //service  layer object
constructor(servicelayer:ServiceLayerService) {this.servicelayer=servicelayer }  //default constructor

  empbean:EmployeeBean;   //employeeBean  object 
  AddDetails(o:any) //addDetaisl method calling
  {
    this.empbean=new EmployeeBean(o.id,o.name,o.email,o.phone);  //updating data from input
    this.servicelayer.AddDetails(this.empbean);//calling adddetails method in service layer 
  }
  ngOnInit() {
  }
}



