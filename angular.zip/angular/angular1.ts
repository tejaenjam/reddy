import { emp, stu } from "../angular/mymodule";
let st=new stu(1,"aravind");
let re1=st.sd1();
console.log('stu details'+re1);
let emp2=new emp("keshireddy","reddy");
let re2=emp2.sd1();
console.log('emp details'+re2);