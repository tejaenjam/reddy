import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CompexamComponent } from './compexam/compexam.component';
import { FormsModule} from '@angular/forms'
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ServService } from './serv.service';
import { Pipes1Pipe } from './pipes1.pipe';

@NgModule({
  declarations: [
    AppComponent,
    CompexamComponent,
    Pipes1Pipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule
  ],
  providers: [HttpClient,ServService],
  bootstrap: [AppComponent]
})
export class AppModule { }
