import { Pipes1Pipe } from './pipes1.pipe';

describe('Pipes1Pipe', () => {
  it('create an instance', () => {
    const pipe = new Pipes1Pipe();
    expect(pipe).toBeTruthy();
  });
});
