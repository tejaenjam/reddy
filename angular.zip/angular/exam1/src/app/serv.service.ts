import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServService {
mob:Nbc[]=[];
ht:HttpClient;
  constructor(ht:HttpClient) {this.ht=ht; }


  ab:boolean=false;
  fet(){
    this.ht.get("./assets/abc.json").subscribe
    (a=>{
      if(!this.ab)
      {
        this.convert(a);
        this.ab=true;
      }
    });
  }
  convert(a :any)
  {
    for(let o of a)
    {
      let e=new Nbc(o.mobId,o.mobName,o.mobPrice)
      this.mob.push(e);
    }
  }

get():Nbc[]
{
return this.mob;
}

delete(o:number)
{
  let  x:number=0;
 for(let i=0;i< this.mob.length;i++)
 {
   let e=this.mob[i];
   if(o==e.mobId)
   {
     x=i;
     break;
   }
 }
 this.mob.splice(x,1);
}


}



export class Nbc{
  
    mobId:number;
    mobName:string;
    mobPrice:number;
    constructor(mobId:number, mobName:string, mobPrice:number)
    {
      this.mobId=mobId;
      this.mobName=mobName;
      this.mobPrice=mobPrice;
    }
    
}
