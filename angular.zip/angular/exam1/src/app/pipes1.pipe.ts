import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipes1'
})
export class Pipes1Pipe implements PipeTransform {

    transform(arr:any[],abc:string){
      //
      // column name is not defined ,no sorting is done
      //
       if(abc==undefined){
         console.log("undefined")
           return arr;
       }
        let result:any[]; 
         result =this.ascending(arr,abc);
         console.log("res :"+result)
         return result;
   }

   /**
    * 
    * @param arr  array which needs to be sorted
    * @param column column name which is used for sorting
    */
   ascending(arr:any[],abc:string){
     console.log("ascending")
       arr.sort((a:any,b:any)=>{
           if(a[abc]>b[abc]){
               return 1;
           }
           return -1;
       });
       return arr;
   }


}