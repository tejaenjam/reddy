import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompexamComponent } from './compexam.component';

describe('CompexamComponent', () => {
  let component: CompexamComponent;
  let fixture: ComponentFixture<CompexamComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompexamComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompexamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
