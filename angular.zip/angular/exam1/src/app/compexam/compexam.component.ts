import { Component, OnInit } from '@angular/core';
import { ServService, Nbc } from '../serv.service';

@Component({
  selector: 'app-compexam',
  templateUrl: './compexam.component.html',
  styleUrls: ['./compexam.component.css']
})
export class CompexamComponent implements OnInit {
ser:ServService;
mob:Nbc[];

  constructor(ser:ServService) {this.ser=ser; }


  ngOnInit() {
    this.ser.fet();
    this.mob=this.ser.get();
  }

  delete(o:number)
  {
    this.ser.delete(o);
    this.mob=this.ser.get();
  }

 abc:any;
  
  sort(abc:string)
  {    console.log("aa")
      this.abc=abc; 
      console.log( this.abc)
  }

}
