import { Component, OnInit, Input } from '@angular/core';
import { compileBaseDefFromMetadata } from '@angular/compiler';

@Component({
  selector: 'aravind',
  templateUrl: './new-cmp.component.html',
  styleUrls: ['./new-cmp.component.css']
})
export class NewCmpComponent implements OnInit {

  aw = new a("Aravind","Reddy","Keshireddy","Qwerty");
   ngOnInit() {
    
  }
} 
class a
{
  a1:string
  a2:string
  a3:string
  a4:string
   constructor(a1:string,a2:string,a3:string,a4:string) {
     this.a1=a1;
     this.a2=a2;
     this.a3=a3;
     this.a4=a4;
     }
}
  