"use strict";
exports.__esModule = true;
var emp = /** @class */ (function () {
    function emp(p1, p2) {
        this.p1 = p1;
        this.p2 = p2;
    }
    emp.prototype.sd1 = function () {
        return this.p1 + " " + this.p2;
    };
    return emp;
}());
exports.emp = emp;
var stu = /** @class */ (function () {
    function stu(p3, p4) {
        this.p3 = p3;
        this.p4 = p4;
    }
    stu.prototype.sd1 = function () {
        return this.p3 + " " + this.p4;
    };
    return stu;
}());
exports.stu = stu;
